-- Criar tabela para solicitações de saque de criadores
CREATE TABLE IF NOT EXISTS creator_payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES model_profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  pix_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  proof_url TEXT,
  notes TEXT,
  requested_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  processed_at TIMESTAMP WITH TIME ZONE,
  CONSTRAINT creator_payouts_status_check CHECK (status IN ('pending', 'processing', 'completed', 'rejected'))
);

-- RLS policies para creator_payouts
ALTER TABLE creator_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profile owners can view own payout requests"
ON creator_payouts FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM model_profiles
    WHERE model_profiles.id = creator_payouts.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

CREATE POLICY "Profile owners can create payout requests"
ON creator_payouts FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM model_profiles
    WHERE model_profiles.id = creator_payouts.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

CREATE POLICY "Admins can manage all payouts"
ON creator_payouts FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));