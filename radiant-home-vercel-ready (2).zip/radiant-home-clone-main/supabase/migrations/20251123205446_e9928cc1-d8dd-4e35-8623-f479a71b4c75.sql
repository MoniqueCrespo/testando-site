-- Remove o trigger que está criando automaticamente role 'visitor'
DROP TRIGGER IF EXISTS on_auth_user_role_created ON auth.users;

-- Remove a função que insere automaticamente role 'visitor'
DROP FUNCTION IF EXISTS public.handle_user_role();

-- Adiciona índice para melhorar performance de consultas de role
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON public.user_roles(user_id);

-- Adiciona política RLS para permitir que usuários insiram seu próprio role apenas durante signup
CREATE POLICY "Users can insert their own role during signup"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);