-- Corrigir search_path nas funções para segurança
CREATE OR REPLACE FUNCTION public.update_support_tickets_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.generate_ticket_number()
RETURNS TEXT 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ticket_count INTEGER;
  new_number TEXT;
BEGIN
  SELECT COUNT(*) INTO ticket_count FROM public.support_tickets;
  new_number := 'TICKET-' || LPAD((ticket_count + 1)::TEXT, 6, '0');
  RETURN new_number;
END;
$$;