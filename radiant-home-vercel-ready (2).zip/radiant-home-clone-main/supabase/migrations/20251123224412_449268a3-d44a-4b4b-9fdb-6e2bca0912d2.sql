-- Create story_reactions table
CREATE TABLE IF NOT EXISTS public.story_reactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id UUID NOT NULL REFERENCES public.profile_stories(id) ON DELETE CASCADE,
  viewer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  reaction_type TEXT NOT NULL CHECK (reaction_type IN ('like', 'love', 'fire', 'clap', 'message')),
  message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.story_reactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for story_reactions
CREATE POLICY "Anyone can insert reactions"
  ON public.story_reactions
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Profile owners can view their story reactions"
  ON public.story_reactions
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profile_stories ps
      JOIN public.model_profiles mp ON ps.profile_id = mp.id
      WHERE ps.id = story_reactions.story_id
      AND mp.user_id = auth.uid()
    )
  );

CREATE POLICY "Viewers can view their own reactions"
  ON public.story_reactions
  FOR SELECT
  USING (auth.uid() = viewer_id);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_story_reactions_story_id ON public.story_reactions(story_id);
CREATE INDEX IF NOT EXISTS idx_story_reactions_viewer_id ON public.story_reactions(viewer_id);