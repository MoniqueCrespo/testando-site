-- Create subscription tiers table
CREATE TABLE IF NOT EXISTS public.subscription_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  tier_name TEXT NOT NULL,
  monthly_price NUMERIC NOT NULL CHECK (monthly_price >= 0),
  description TEXT,
  benefits JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create exclusive content table
CREATE TABLE IF NOT EXISTS public.exclusive_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  media_type TEXT NOT NULL CHECK (media_type IN ('image', 'video')),
  media_url TEXT NOT NULL,
  thumbnail_url TEXT,
  caption TEXT,
  is_preview BOOLEAN DEFAULT false,
  required_tier_id UUID REFERENCES public.subscription_tiers(id) ON DELETE SET NULL,
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create content subscriptions table
CREATE TABLE IF NOT EXISTS public.content_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  tier_id UUID NOT NULL REFERENCES public.subscription_tiers(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired', 'pending')),
  start_date TIMESTAMP WITH TIME ZONE DEFAULT now(),
  end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  auto_renew BOOLEAN DEFAULT true,
  payment_method TEXT DEFAULT 'mercadopago',
  payment_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create subscription payments table
CREATE TABLE IF NOT EXISTS public.subscription_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id UUID NOT NULL REFERENCES public.content_subscriptions(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  platform_fee NUMERIC NOT NULL,
  creator_amount NUMERIC NOT NULL,
  payment_id TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'refunded')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create creator earnings table
CREATE TABLE IF NOT EXISTS public.creator_earnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL UNIQUE REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  total_earned NUMERIC DEFAULT 0 CHECK (total_earned >= 0),
  platform_fee_total NUMERIC DEFAULT 0 CHECK (platform_fee_total >= 0),
  pending_payout NUMERIC DEFAULT 0 CHECK (pending_payout >= 0),
  paid_out NUMERIC DEFAULT 0 CHECK (paid_out >= 0),
  last_payout_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create content views table for analytics
CREATE TABLE IF NOT EXISTS public.content_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL REFERENCES public.exclusive_content(id) ON DELETE CASCADE,
  viewer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  viewed_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_subscription_tiers_profile ON public.subscription_tiers(profile_id);
CREATE INDEX IF NOT EXISTS idx_exclusive_content_profile ON public.exclusive_content(profile_id);
CREATE INDEX IF NOT EXISTS idx_content_subscriptions_subscriber ON public.content_subscriptions(subscriber_id);
CREATE INDEX IF NOT EXISTS idx_content_subscriptions_profile ON public.content_subscriptions(profile_id);
CREATE INDEX IF NOT EXISTS idx_content_subscriptions_status ON public.content_subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscription_payments_subscription ON public.subscription_payments(subscription_id);
CREATE INDEX IF NOT EXISTS idx_creator_earnings_profile ON public.creator_earnings(profile_id);
CREATE INDEX IF NOT EXISTS idx_content_views_content ON public.content_views(content_id);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION public.update_subscription_tiers_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_subscription_tiers_updated_at
  BEFORE UPDATE ON public.subscription_tiers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_subscription_tiers_updated_at();

CREATE OR REPLACE FUNCTION public.update_content_subscriptions_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_content_subscriptions_updated_at
  BEFORE UPDATE ON public.content_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_content_subscriptions_updated_at();

CREATE OR REPLACE FUNCTION public.update_creator_earnings_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_creator_earnings_updated_at
  BEFORE UPDATE ON public.creator_earnings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_creator_earnings_updated_at();

-- Enable RLS
ALTER TABLE public.subscription_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exclusive_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_views ENABLE ROW LEVEL SECURITY;

-- RLS Policies for subscription_tiers
CREATE POLICY "Anyone can view active tiers"
  ON public.subscription_tiers FOR SELECT
  USING (is_active = true);

CREATE POLICY "Profile owners can manage their tiers"
  ON public.subscription_tiers FOR ALL
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = subscription_tiers.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all tiers"
  ON public.subscription_tiers FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for exclusive_content
CREATE POLICY "Anyone can view preview content"
  ON public.exclusive_content FOR SELECT
  USING (is_preview = true);

CREATE POLICY "Subscribers can view paid content"
  ON public.exclusive_content FOR SELECT
  USING (
    is_preview = true OR
    EXISTS (
      SELECT 1 FROM public.content_subscriptions cs
      JOIN public.subscription_tiers st ON cs.tier_id = st.id
      WHERE cs.subscriber_id = auth.uid()
      AND cs.profile_id = exclusive_content.profile_id
      AND cs.status = 'active'
      AND cs.end_date > now()
      AND (exclusive_content.required_tier_id IS NULL OR st.sort_order >= (
        SELECT sort_order FROM public.subscription_tiers WHERE id = exclusive_content.required_tier_id
      ))
    )
  );

CREATE POLICY "Profile owners can manage their content"
  ON public.exclusive_content FOR ALL
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = exclusive_content.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all content"
  ON public.exclusive_content FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for content_subscriptions
CREATE POLICY "Users can view own subscriptions"
  ON public.content_subscriptions FOR SELECT
  USING (subscriber_id = auth.uid());

CREATE POLICY "Profile owners can view their subscribers"
  ON public.content_subscriptions FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = content_subscriptions.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Users can create own subscriptions"
  ON public.content_subscriptions FOR INSERT
  WITH CHECK (subscriber_id = auth.uid());

CREATE POLICY "Users can update own subscriptions"
  ON public.content_subscriptions FOR UPDATE
  USING (subscriber_id = auth.uid());

CREATE POLICY "Admins can manage all subscriptions"
  ON public.content_subscriptions FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for subscription_payments
CREATE POLICY "Users can view own payments"
  ON public.subscription_payments FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.content_subscriptions
    WHERE content_subscriptions.id = subscription_payments.subscription_id
    AND content_subscriptions.subscriber_id = auth.uid()
  ));

CREATE POLICY "Profile owners can view their payments"
  ON public.subscription_payments FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.content_subscriptions cs
    JOIN public.model_profiles mp ON cs.profile_id = mp.id
    WHERE cs.id = subscription_payments.subscription_id
    AND mp.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all payments"
  ON public.subscription_payments FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for creator_earnings
CREATE POLICY "Profile owners can view own earnings"
  ON public.creator_earnings FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = creator_earnings.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all earnings"
  ON public.creator_earnings FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for content_views
CREATE POLICY "Profile owners can view their content analytics"
  ON public.content_views FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.exclusive_content ec
    JOIN public.model_profiles mp ON ec.profile_id = mp.id
    WHERE ec.id = content_views.content_id
    AND mp.user_id = auth.uid()
  ));

CREATE POLICY "Users can create view records"
  ON public.content_views FOR INSERT
  WITH CHECK (viewer_id = auth.uid());

CREATE POLICY "Admins can view all analytics"
  ON public.content_views FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Create storage bucket for exclusive content
INSERT INTO storage.buckets (id, name, public)
VALUES ('exclusive-content', 'exclusive-content', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for exclusive-content bucket
CREATE POLICY "Profile owners can upload exclusive content"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'exclusive-content' AND
    EXISTS (
      SELECT 1 FROM public.model_profiles
      WHERE model_profiles.user_id = auth.uid()
      AND model_profiles.id::text = (storage.foldername(name))[1]
    )
  );

CREATE POLICY "Profile owners can update their exclusive content"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'exclusive-content' AND
    EXISTS (
      SELECT 1 FROM public.model_profiles
      WHERE model_profiles.user_id = auth.uid()
      AND model_profiles.id::text = (storage.foldername(name))[1]
    )
  );

CREATE POLICY "Profile owners can delete their exclusive content"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'exclusive-content' AND
    EXISTS (
      SELECT 1 FROM public.model_profiles
      WHERE model_profiles.user_id = auth.uid()
      AND model_profiles.id::text = (storage.foldername(name))[1]
    )
  );

CREATE POLICY "Subscribers can view exclusive content"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'exclusive-content' AND
    EXISTS (
      SELECT 1 FROM public.content_subscriptions cs
      WHERE cs.subscriber_id = auth.uid()
      AND cs.profile_id::text = (storage.foldername(name))[1]
      AND cs.status = 'active'
      AND cs.end_date > now()
    )
  );

CREATE POLICY "Admins can manage all exclusive content"
  ON storage.objects FOR ALL
  USING (
    bucket_id = 'exclusive-content' AND
    has_role(auth.uid(), 'admin'::app_role)
  );