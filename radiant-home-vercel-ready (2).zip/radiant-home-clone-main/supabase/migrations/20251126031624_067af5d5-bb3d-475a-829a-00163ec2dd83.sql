-- Enable replica identity for realtime (if not already set)
ALTER TABLE public.client_messages REPLICA IDENTITY FULL;

-- Create indexes for better performance on message queries
CREATE INDEX IF NOT EXISTS idx_client_messages_sender_receiver 
ON public.client_messages(sender_id, receiver_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_client_messages_profile 
ON public.client_messages(profile_id, created_at DESC);

-- Create index for unread messages
CREATE INDEX IF NOT EXISTS idx_client_messages_unread 
ON public.client_messages(receiver_id, read_at) 
WHERE read_at IS NULL;