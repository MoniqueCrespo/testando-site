-- Enable RLS on profile_stories if not already enabled
ALTER TABLE profile_stories ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view all active stories" ON profile_stories;
DROP POLICY IF EXISTS "Profile owners can insert stories" ON profile_stories;
DROP POLICY IF EXISTS "Profile owners can delete their stories" ON profile_stories;

-- Allow anyone to view stories (public access for browsing)
CREATE POLICY "Users can view all active stories"
ON profile_stories
FOR SELECT
USING (true);

-- Allow profile owners to insert stories
-- Users can insert stories for profiles they own
CREATE POLICY "Profile owners can insert stories"
ON profile_stories
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM model_profiles
    WHERE model_profiles.id = profile_stories.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

-- Allow profile owners to delete their own stories
CREATE POLICY "Profile owners can delete their stories"
ON profile_stories
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM model_profiles
    WHERE model_profiles.id = profile_stories.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);