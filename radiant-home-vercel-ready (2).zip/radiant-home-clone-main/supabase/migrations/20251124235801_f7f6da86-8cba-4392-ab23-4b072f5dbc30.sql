-- Corrigir funções com search_path mutable
CREATE OR REPLACE FUNCTION update_auto_renewal_settings_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;