-- Create feed_interactions table for tracking user engagement
create table if not exists public.feed_interactions (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.model_profiles(id) on delete cascade,
  viewer_id uuid references auth.users(id) on delete set null,
  interaction_type text not null check (interaction_type in ('view', 'favorite', 'profile_visit', 'message')),
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.feed_interactions enable row level security;

-- Allow anyone to insert interactions (including anonymous users)
create policy "Anyone can insert interactions"
  on public.feed_interactions
  for insert
  with check (true);

-- Profile owners can view interactions with their profiles
create policy "Profile owners can view their interactions"
  on public.feed_interactions
  for select
  using (
    exists (
      select 1 from public.model_profiles
      where model_profiles.id = feed_interactions.profile_id
      and model_profiles.user_id = auth.uid()
    )
  );

-- Create index for faster queries
create index if not exists idx_feed_interactions_profile_id on public.feed_interactions(profile_id);
create index if not exists idx_feed_interactions_viewer_id on public.feed_interactions(viewer_id);
create index if not exists idx_feed_interactions_created_at on public.feed_interactions(created_at desc);