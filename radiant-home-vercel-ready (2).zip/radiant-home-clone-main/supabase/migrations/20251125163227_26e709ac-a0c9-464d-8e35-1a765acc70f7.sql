-- Create profile_leads table for CRM functionality
CREATE TABLE IF NOT EXISTS public.profile_leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  contact_name TEXT,
  contact_phone TEXT,
  contact_email TEXT,
  source TEXT NOT NULL DEFAULT 'whatsapp',
  notes TEXT,
  tags TEXT[] DEFAULT '{}',
  status TEXT DEFAULT 'new',
  contacted_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profile_leads ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Profile owners can manage their leads"
  ON public.profile_leads
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.model_profiles
      WHERE model_profiles.id = profile_leads.profile_id
      AND model_profiles.user_id = auth.uid()
    )
  );

-- Create trigger for updated_at
CREATE TRIGGER update_profile_leads_updated_at
  BEFORE UPDATE ON public.profile_leads
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for better performance
CREATE INDEX idx_profile_leads_profile_id ON public.profile_leads(profile_id);
CREATE INDEX idx_profile_leads_user_id ON public.profile_leads(user_id);
CREATE INDEX idx_profile_leads_status ON public.profile_leads(status);