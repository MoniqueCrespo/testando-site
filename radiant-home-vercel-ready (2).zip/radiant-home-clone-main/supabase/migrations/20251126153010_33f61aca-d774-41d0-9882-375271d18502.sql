-- Add max_photos column to premium_plans table
ALTER TABLE premium_plans ADD COLUMN IF NOT EXISTS max_photos INTEGER DEFAULT 10;

-- Update existing plans with photo limits following market standards
-- Free plan: 4 photos (defined in code)
-- 7 days plan: 6 photos
UPDATE premium_plans SET max_photos = 6 WHERE duration_days = 7;

-- 15 days plan: 8 photos
UPDATE premium_plans SET max_photos = 8 WHERE duration_days = 15;

-- 30 days plan: 10 photos
UPDATE premium_plans SET max_photos = 10 WHERE duration_days = 30;