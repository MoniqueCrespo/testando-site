-- Add body_type and ethnicity columns to model_profiles
ALTER TABLE public.model_profiles 
ADD COLUMN IF NOT EXISTS body_type TEXT,
ADD COLUMN IF NOT EXISTS ethnicity TEXT;