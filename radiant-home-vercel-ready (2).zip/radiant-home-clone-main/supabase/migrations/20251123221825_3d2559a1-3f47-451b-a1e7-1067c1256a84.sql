-- Create profile_reviews table for rating system
CREATE TABLE IF NOT EXISTS public.profile_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  is_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_reviews_profile ON public.profile_reviews(profile_id);
CREATE INDEX idx_reviews_created ON public.profile_reviews(created_at DESC);
CREATE INDEX idx_reviews_user ON public.profile_reviews(user_id);

-- Enable RLS
ALTER TABLE public.profile_reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Anyone can view verified reviews
CREATE POLICY "Anyone can view verified reviews"
  ON public.profile_reviews
  FOR SELECT
  USING (is_verified = true);

-- Authenticated users can view their own reviews (even if not verified yet)
CREATE POLICY "Users can view their own reviews"
  ON public.profile_reviews
  FOR SELECT
  USING (auth.uid() = user_id);

-- Authenticated users can create reviews
CREATE POLICY "Authenticated users can create reviews"
  ON public.profile_reviews
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own reviews within 24 hours
CREATE POLICY "Users can update own reviews within 24h"
  ON public.profile_reviews
  FOR UPDATE
  USING (
    auth.uid() = user_id 
    AND created_at > (now() - interval '24 hours')
  );

-- Trigger to update updated_at
CREATE TRIGGER update_profile_reviews_updated_at
  BEFORE UPDATE ON public.profile_reviews
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();