-- Remover políticas existentes do bucket exclusive-content
DROP POLICY IF EXISTS "Models can upload exclusive content to own profile" ON storage.objects;
DROP POLICY IF EXISTS "Models can update own exclusive content" ON storage.objects;
DROP POLICY IF EXISTS "Models can delete own exclusive content" ON storage.objects;
DROP POLICY IF EXISTS "Subscribers can view exclusive content" ON storage.objects;

-- Recriar políticas RLS para o bucket exclusive-content

-- Permitir que modelos façam upload de conteúdo para seus próprios perfis
CREATE POLICY "Models can upload exclusive content to own profile"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'exclusive-content' 
  AND (storage.foldername(name))[1] IN (
    SELECT id::text 
    FROM model_profiles 
    WHERE user_id = auth.uid()
  )
);

-- Permitir que modelos atualizem conteúdo dos seus perfis
CREATE POLICY "Models can update own exclusive content"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'exclusive-content'
  AND (storage.foldername(name))[1] IN (
    SELECT id::text 
    FROM model_profiles 
    WHERE user_id = auth.uid()
  )
);

-- Permitir que modelos deletem conteúdo dos seus perfis
CREATE POLICY "Models can delete own exclusive content"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'exclusive-content'
  AND (storage.foldername(name))[1] IN (
    SELECT id::text 
    FROM model_profiles 
    WHERE user_id = auth.uid()
  )
);

-- Permitir que assinantes ativos e donos visualizem conteúdo exclusivo
CREATE POLICY "Subscribers can view exclusive content"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'exclusive-content'
  AND (
    -- Donos dos perfis podem ver
    (storage.foldername(name))[1] IN (
      SELECT id::text 
      FROM model_profiles 
      WHERE user_id = auth.uid()
    )
    OR
    -- Assinantes ativos podem ver
    EXISTS (
      SELECT 1 
      FROM content_subscriptions cs
      JOIN model_profiles mp ON cs.profile_id = mp.id
      WHERE cs.subscriber_id = auth.uid()
        AND cs.status = 'active'
        AND cs.end_date > now()
        AND (storage.foldername(name))[1] = mp.id::text
    )
  )
);