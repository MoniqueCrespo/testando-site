-- Criar tabela de categorias gerenciáveis
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Criar tabela de etnias gerenciáveis
CREATE TABLE IF NOT EXISTS public.ethnicities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Criar tabela de cidades gerenciáveis
CREATE TABLE IF NOT EXISTS public.cities_seo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  state_code TEXT NOT NULL,
  state_name TEXT NOT NULL,
  city_name TEXT NOT NULL,
  city_slug TEXT NOT NULL,
  meta_title TEXT,
  meta_description TEXT,
  canonical_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE(state_code, city_slug)
);

-- Criar tabela de blocos de conteúdo (CMS)
CREATE TABLE IF NOT EXISTS public.content_blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  content TEXT,
  block_type TEXT NOT NULL DEFAULT 'text',
  page TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Criar tabela de páginas dinâmicas
CREATE TABLE IF NOT EXISTS public.dynamic_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  content TEXT,
  meta_title TEXT,
  meta_description TEXT,
  is_published BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  published_at TIMESTAMP WITH TIME ZONE
);

-- Criar tabela de configurações de SEO
CREATE TABLE IF NOT EXISTS public.seo_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE,
  value TEXT,
  description TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Criar tabela de itens de menu
CREATE TABLE IF NOT EXISTS public.menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  menu_type TEXT NOT NULL,
  label TEXT NOT NULL,
  url TEXT NOT NULL,
  parent_id UUID REFERENCES public.menu_items(id) ON DELETE CASCADE,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Criar índices
CREATE INDEX IF NOT EXISTS idx_categories_slug ON public.categories(slug);
CREATE INDEX IF NOT EXISTS idx_cities_seo_state ON public.cities_seo(state_code);
CREATE INDEX IF NOT EXISTS idx_cities_seo_slug ON public.cities_seo(city_slug);
CREATE INDEX IF NOT EXISTS idx_content_blocks_key ON public.content_blocks(key);
CREATE INDEX IF NOT EXISTS idx_dynamic_pages_slug ON public.dynamic_pages(slug);
CREATE INDEX IF NOT EXISTS idx_menu_items_type ON public.menu_items(menu_type);

-- Funções de update
CREATE OR REPLACE FUNCTION public.update_categories_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_cities_seo_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_content_blocks_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_dynamic_pages_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Triggers
DROP TRIGGER IF EXISTS update_categories_updated_at ON public.categories;
CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON public.categories
  FOR EACH ROW
  EXECUTE FUNCTION public.update_categories_updated_at();

DROP TRIGGER IF EXISTS update_cities_seo_updated_at ON public.cities_seo;
CREATE TRIGGER update_cities_seo_updated_at
  BEFORE UPDATE ON public.cities_seo
  FOR EACH ROW
  EXECUTE FUNCTION public.update_cities_seo_updated_at();

DROP TRIGGER IF EXISTS update_content_blocks_updated_at ON public.content_blocks;
CREATE TRIGGER update_content_blocks_updated_at
  BEFORE UPDATE ON public.content_blocks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_content_blocks_updated_at();

DROP TRIGGER IF EXISTS update_dynamic_pages_updated_at ON public.dynamic_pages;
CREATE TRIGGER update_dynamic_pages_updated_at
  BEFORE UPDATE ON public.dynamic_pages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_dynamic_pages_updated_at();

-- Habilitar RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ethnicities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cities_seo ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dynamic_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seo_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;

-- Políticas RLS - Somente admins podem gerenciar
CREATE POLICY "Admins podem gerenciar categorias"
  ON public.categories FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar etnias"
  ON public.ethnicities FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar cidades SEO"
  ON public.cities_seo FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar blocos de conteúdo"
  ON public.content_blocks FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar páginas dinâmicas"
  ON public.dynamic_pages FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar configurações SEO"
  ON public.seo_settings FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins podem gerenciar menu"
  ON public.menu_items FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas públicas de leitura
CREATE POLICY "Todos podem ver categorias ativas"
  ON public.categories FOR SELECT
  USING (is_active = true);

CREATE POLICY "Todos podem ver etnias ativas"
  ON public.ethnicities FOR SELECT
  USING (is_active = true);

CREATE POLICY "Todos podem ver cidades ativas"
  ON public.cities_seo FOR SELECT
  USING (is_active = true);

CREATE POLICY "Todos podem ver blocos de conteúdo ativos"
  ON public.content_blocks FOR SELECT
  USING (is_active = true);

CREATE POLICY "Todos podem ver páginas publicadas"
  ON public.dynamic_pages FOR SELECT
  USING (is_published = true);

CREATE POLICY "Todos podem ver configurações SEO"
  ON public.seo_settings FOR SELECT
  USING (true);

CREATE POLICY "Todos podem ver menu ativo"
  ON public.menu_items FOR SELECT
  USING (is_active = true);

-- Inserir configurações SEO padrão
INSERT INTO public.seo_settings (key, value, description) VALUES
  ('site_name', 'Acompanhantes Brasil', 'Nome do site'),
  ('default_meta_title', 'Acompanhantes Brasil - O melhor guia', 'Meta title padrão'),
  ('default_meta_description', 'Encontre acompanhantes verificados em todo Brasil', 'Meta description padrão'),
  ('og_image', '', 'URL da imagem OpenGraph padrão'),
  ('google_analytics_id', '', 'ID do Google Analytics (GA4)'),
  ('google_site_verification', '', 'Código de verificação do Google Search Console')
ON CONFLICT (key) DO NOTHING;