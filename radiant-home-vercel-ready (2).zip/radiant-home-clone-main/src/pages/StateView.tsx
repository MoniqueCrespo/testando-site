import React from "react";
import { useLocation } from "@/hooks/useLocation";
import { getCitiesByState, getNeighborhoodsByCity } from "@/data/locations";
import { useSearchParams, useNavigate } from "react-router-dom";
import { useFilters } from "@/hooks/useFilters";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { CategoryType } from "@/types/location";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import LocationSelector from "@/components/LocationSelector";
import CityCard from "@/components/CityCard";
import SEOHead from "@/components/SEOHead";
import FilterBar from "@/components/FilterBar";
import AdvancedFilters from "@/components/AdvancedFilters";
import ProfileCard from "@/components/ProfileCard";
import ProfileListItem from "@/components/ProfileListItem";
import ProfileCardSkeleton from "@/components/ProfileCardSkeleton";
import ProfileListItemSkeleton from "@/components/ProfileListItemSkeleton";
import InternalNavigation from "@/components/InternalNavigation";
import { EmptyState } from "@/components/EmptyState";
import { StoriesBar } from "@/components/StoriesBar";
import { NeighboringStates } from "@/components/NeighboringStates";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Users, User, Sparkles, Heart, Flower2, Building2, X, Loader2 } from "lucide-react";
import { useState, useEffect, useMemo, useCallback } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const StateView = () => {
  const { state, city, category, changeCategory } = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [profiles, setProfiles] = useState<Tables<'model_profiles'>[]>([]);
  const [neighborhoodCounts, setNeighborhoodCounts] = useState<Record<string, number>>({});
  const [isLoadingNeighborhoods, setIsLoadingNeighborhoods] = useState(true);
  const [displayedCount, setDisplayedCount] = useState(12);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const BATCH_SIZE = 12;
  
  const {
    filters,
    updateFilter,
    resetFilters,
    savedFilters,
    saveCurrentFilters,
    loadSavedFilter,
    deleteSavedFilter,
  } = useFilters();
  
  if (!state) {
    navigate("/");
    return null;
  }

  const cities = getCitiesByState(state.code);
  
  // Buscar perfis do Supabase - agora com suporte a filtro por cidade
  useEffect(() => {
    const fetchProfiles = async () => {
      setIsLoading(true);
      
      let query = supabase
        .from('model_profiles')
        .select('*')
        .eq('state', state.code)
        .eq('is_active', true)
        .eq('moderation_status', 'approved');
      
      // Se tem city na URL, filtra apenas por essa cidade
      if (city) {
        query = query.eq('city', city.slug);
      }
      
      const { data, error } = await query
        .order('featured', { ascending: false })
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching profiles:', error);
      } else {
        setProfiles(data || []);
      }
      setIsLoading(false);
    };
    
    fetchProfiles();
  }, [state.slug, city?.slug]);
  
  // Buscar contagem de perfis por bairro
  useEffect(() => {
    const fetchNeighborhoodCounts = async () => {
      setIsLoadingNeighborhoods(true);
      
      const { data, error } = await supabase
        .from('model_profiles')
        .select('neighborhoods')
        .eq('state', state.code)
        .eq('category', category)
        .eq('is_active', true)
        .eq('moderation_status', 'approved');
      
      if (error) {
        console.error('Error fetching neighborhood counts:', error);
        setIsLoadingNeighborhoods(false);
        return;
      }
      
      // Agregar contagens por bairro
      const counts: Record<string, number> = {};
      data?.forEach(profile => {
        profile.neighborhoods?.forEach(neighborhood => {
          const normalized = neighborhood.toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");
          counts[normalized] = (counts[normalized] || 0) + 1;
        });
      });
      
      setNeighborhoodCounts(counts);
      setIsLoadingNeighborhoods(false);
    };
    
    fetchNeighborhoodCounts();
  }, [state.code, category]);
  
  // Calcular contagem de perfis por categoria
  const getCategoryCount = (cat: CategoryType) => {
    return profiles.filter(p => p.category === cat).length;
  };
  
  const categoryLabels = {
    mulheres: 'Acompanhantes',
    homens: 'Homens',
    trans: 'Trans',
    casais: 'Casais',
    massagistas: 'Massagistas'
  };
  
  // Transformar perfil do Supabase para formato do componente
  const transformProfile = (profile: Tables<'model_profiles'>) => ({
    ...profile,
    id: profile.id,
    slug: (profile as any).slug, // Campo slug adicionado para URLs amigáveis
    location: `${profile.city}, ${profile.state}`,
    image: profile.photo_url || profile.photos?.[0] || '/placeholder.svg',
    rating: 4.5, // Mock rating - pode implementar sistema de avaliações depois
    tags: [],
    isNew: new Date(profile.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
    isOnline: Math.random() > 0.5, // Mock online status
    eyeColor: profile.eye_color,
    hairColor: profile.hair_color,
  });
  
  // Filtrar perfis do estado pela categoria ativa
  const stateProfiles = profiles.filter(profile => profile.category === category);
  
  // Separar perfis premium/featured para o carrossel
  const premiumProfiles = useMemo(() => 
    stateProfiles.filter(p => p.featured), 
    [stateProfiles]
  );
  
  // Ler query params da URL
  const servicoParam = searchParams.get('servico');
  const bairroParam = searchParams.get('bairro');
  
  // Scroll automático ao topo quando filtros de URL mudam
  useEffect(() => {
    if (servicoParam || bairroParam) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [servicoParam, bairroParam]);
  
  // Aplicar filtro de cidade dos filtros avançados
  let filteredProfiles = filters.city === "all" 
    ? stateProfiles 
    : stateProfiles.filter(p => p.city === filters.city);
  
  // Aplicar filtros de categoria
  if (selectedCategory === "Destaque") {
    filteredProfiles = filteredProfiles.filter(p => p.featured);
  } else if (selectedCategory === "Verificados") {
    filteredProfiles = filteredProfiles.filter(p => p.verified);
  } else if (selectedCategory === "Premium") {
    filteredProfiles = filteredProfiles.filter(p => p.price >= 500);
  } else if (selectedCategory === "Novos") {
    filteredProfiles = filteredProfiles.slice(0, 12);
  }
  
  // Aplicar filtros avançados
  filteredProfiles = filteredProfiles.filter(profile => {
    // Filtro de nome
    if (filters.searchName && !profile.name.toLowerCase().includes(filters.searchName.toLowerCase())) {
      return false;
    }
    
    // Filtro de idade
    if (profile.age < filters.ageRange[0] || profile.age > filters.ageRange[1]) {
      return false;
    }
    
    // Filtro de preço
    if (profile.price < filters.priceRange[0] || profile.price > filters.priceRange[1]) {
      return false;
    }
    
    // Filtro de altura
    if (profile.height && (profile.height < filters.height[0] || profile.height > filters.height[1])) {
      return false;
    }
    
    // Filtro de peso
    if (profile.weight && (profile.weight < filters.weight[0] || profile.weight > filters.weight[1])) {
      return false;
    }
    
    // Filtro de cor dos olhos
    if (filters.eyeColor.length > 0 && profile.eye_color && !filters.eyeColor.includes(profile.eye_color)) {
      return false;
    }
    
    // Filtro de cor do cabelo
    if (filters.hairColor.length > 0 && profile.hair_color && !filters.hairColor.includes(profile.hair_color)) {
      return false;
    }
    
    // Filtro de serviços
    if (filters.services.length > 0 && profile.services) {
      const hasService = filters.services.some(s => profile.services.includes(s));
      if (!hasService) return false;
    }
    
    // Filtro de disponibilidade
    if (filters.availability.length > 0 && profile.availability) {
      const hasAvailability = filters.availability.some(a => profile.availability.includes(a));
      if (!hasAvailability) return false;
    }
    
    // Filtro de bairro
    if (filters.neighborhoods.length > 0 && profile.neighborhoods) {
      const hasNeighborhood = filters.neighborhoods.some(n => profile.neighborhoods.includes(n));
      if (!hasNeighborhood) return false;
    }
    
    return true;
  });
  
  // Aplicar filtro de serviço (especialidade) da URL
  if (servicoParam) {
    filteredProfiles = filteredProfiles.filter(profile => {
      if (!profile.services) return false;
      const normalizedServices = profile.services.map(s => 
        s.toLowerCase()
         .normalize("NFD")
         .replace(/[\u0300-\u036f]/g, "")
         .replace(/[^a-z0-9]+/g, "-")
      );
      return normalizedServices.includes(servicoParam);
    });
  }
  
  // Aplicar filtro de bairro da URL
  if (bairroParam) {
    filteredProfiles = filteredProfiles.filter(profile => {
      if (!profile.neighborhoods) return false;
      const normalizedNeighborhoods = profile.neighborhoods.map(n => 
        n.toLowerCase()
         .normalize("NFD")
         .replace(/[\u0300-\u036f]/g, "")
         .replace(/[^a-z0-9]+/g, "-")
      );
      return normalizedNeighborhoods.includes(bairroParam);
    });
  }
  
  // Scroll infinito
  const currentProfiles = filteredProfiles.slice(0, displayedCount);
  const hasMore = displayedCount < filteredProfiles.length;

  // Reset displayedCount quando filtros mudam
  useEffect(() => {
    setDisplayedCount(BATCH_SIZE);
  }, [filters, selectedCategory, servicoParam, bairroParam]);

  // Infinite scroll listener
  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.innerHeight + window.scrollY;
      const threshold = document.documentElement.scrollHeight - 500;
      
      if (scrolled >= threshold && !isLoadingMore && hasMore) {
        setIsLoadingMore(true);
        setTimeout(() => {
          setDisplayedCount(prev => prev + BATCH_SIZE);
          setIsLoadingMore(false);
        }, 300);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoadingMore, hasMore]);
  
  // Função para limpar filtros de URL
  const clearUrlFilters = () => {
    setSearchParams({});
  };
  
  // Denormalizar slugs para exibição
  const denormalizeSlug = (slug: string) => {
    return slug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };
  
  
  // Cidades em destaque (top 6 com mais perfis da categoria ativa)
  const citiesWithCount = cities.map(city => ({
    ...city,
    count: profiles.filter(p => p.city === city.slug && p.category === category).length
  })).sort((a, b) => b.count - a.count).slice(0, 6);

  // Meta tags dinâmicas para SEO
  const categoryTitle = category === 'mulheres' ? 'Acompanhantes' : `Acompanhantes ${categoryLabels[category]}`;
  const pageTitle = `${categoryTitle} em ${state.name} | ${stateProfiles.length} Perfis Verificados`;
  const cityNames = citiesWithCount.slice(0, 3).map(c => c.name).join(', ');
  const pageDescription = `Encontre ${categoryTitle.toLowerCase()} em ${state.name}. ${stateProfiles.length} perfis em ${cities.length} cidades. Atendimento nas cidades: ${cityNames} e mais.`;
  const pageKeywords = `${categoryTitle.toLowerCase()} ${state.name}, escorts ${state.name}, ${category} ${state.name}, ${state.code}`;
  const canonicalUrl = category === 'mulheres' 
    ? `${window.location.origin}/acompanhantes/${state.code.toLowerCase()}`
    : `${window.location.origin}/acompanhantes/${state.code.toLowerCase()}/${category}`;

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title={pageTitle}
        description={pageDescription}
        keywords={pageKeywords}
        canonical={canonicalUrl}
      />
      <Header />
      <LocationSelector />
      
      <main className="container mx-auto px-4 py-8">
        <StoriesBar 
          stateSlug={state.code}
          category={category}
        />
        
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Estados
          </Button>
          
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            {categoryTitle} em {state.name}
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-muted-foreground mb-6">
            <p>
              {filteredProfiles.length} {filteredProfiles.length === 1 ? 'perfil disponível' : 'perfis disponíveis'}
            </p>
            {filters.city !== "all" && (
              <Badge variant="secondary" className="gap-1">
                <MapPin className="h-3 w-3" />
                {cities.find(c => c.slug === filters.city)?.name}
              </Badge>
            )}
            {filters.neighborhoods.length > 0 && (
              <Badge variant="secondary" className="gap-1">
                <Building2 className="h-3 w-3" />
                {filters.neighborhoods.length} bairro{filters.neighborhoods.length > 1 ? 's' : ''}
              </Badge>
            )}
            {servicoParam && (
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="h-3 w-3" />
                {denormalizeSlug(servicoParam)}
                <X 
                  className="h-3 w-3 ml-1 cursor-pointer hover:text-destructive" 
                  onClick={() => {
                    searchParams.delete('servico');
                    setSearchParams(searchParams);
                  }}
                />
              </Badge>
            )}
            {bairroParam && (
              <Badge variant="secondary" className="gap-1">
                <Building2 className="h-3 w-3" />
                {denormalizeSlug(bairroParam)}
                <X 
                  className="h-3 w-3 ml-1 cursor-pointer hover:text-destructive" 
                  onClick={() => {
                    searchParams.delete('bairro');
                    setSearchParams(searchParams);
                  }}
                />
              </Badge>
            )}
            {(servicoParam || bairroParam) && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearUrlFilters}
                className="h-6 px-2 text-xs"
              >
                Limpar filtros
              </Button>
            )}
          </div>
        </div>

        {/* Botões de Categoria */}
        <div className="mb-4">
          <div className="bg-card border border-border rounded-lg p-1.5">
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
                <Button
                  variant={category === 'mulheres' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    changeCategory('mulheres');
                  }}
                  className={`gap-2 min-w-[140px] ${
                    category === 'mulheres' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                <Users className="w-4 h-4" />
                Mulheres
                <Badge variant="secondary" className="ml-auto">
                  {getCategoryCount('mulheres')}
                </Badge>
              </Button>
              
                <Button
                  variant={category === 'homens' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    changeCategory('homens');
                  }}
                  className={`gap-2 min-w-[140px] ${
                    category === 'homens' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                <User className="w-4 h-4" />
                Homens
                <Badge variant="secondary" className="ml-auto">
                  {getCategoryCount('homens')}
                </Badge>
              </Button>
              
                <Button
                  variant={category === 'trans' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    changeCategory('trans');
                  }}
                  className={`gap-2 min-w-[140px] ${
                    category === 'trans' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                <Sparkles className="w-4 h-4" />
                Trans
                <Badge variant="secondary" className="ml-auto">
                  {getCategoryCount('trans')}
                </Badge>
              </Button>
              
                <Button
                  variant={category === 'casais' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    changeCategory('casais');
                  }}
                  className={`gap-2 min-w-[140px] ${
                    category === 'casais' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                <Heart className="w-4 h-4" />
                Casais
                <Badge variant="secondary" className="ml-auto">
                  {getCategoryCount('casais')}
                </Badge>
              </Button>
              
                <Button
                  variant={category === 'massagistas' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    changeCategory('massagistas');
                  }}
                  className={`gap-2 min-w-[140px] ${
                    category === 'massagistas' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                <Flower2 className="w-4 h-4" />
                Massagistas
                <Badge variant="secondary" className="ml-auto">
                  {getCategoryCount('massagistas')}
                </Badge>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Carrossel de Perfis Premium */}
        {premiumProfiles.length > 0 && (
          <section className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold text-foreground">Perfis em Destaque</h2>
                <Badge variant="outline" className="text-xs">• {state.name}</Badge>
              </div>
              <Badge variant="secondary" className="text-xs">Premium</Badge>
            </div>
            
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent>
                {premiumProfiles.map((profile) => {
                  const transformed = transformProfile(profile);
                  return (
                    <CarouselItem key={profile.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                      <ProfileCard 
                        {...transformed}
                        state={profile.state}
                        city={profile.city}
                        category={profile.category}
                        services={profile.services || []}
                      />
                    </CarouselItem>
                  );
                })}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </section>
        )}
        
        <FilterBar
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          onFiltersClick={() => setFiltersOpen(true)}
          selectedCategory={selectedCategory}
          onCategoryChange={(cat) => {
            setSelectedCategory(cat);
          }}
        />
        
        <AdvancedFilters
          open={filtersOpen}
          onOpenChange={setFiltersOpen}
          filters={filters}
          onFilterChange={(key, value) => {
            updateFilter(key, value);
          }}
          onReset={resetFilters}
          savedFilters={savedFilters}
          onSaveFilters={saveCurrentFilters}
          onLoadFilter={loadSavedFilter}
          onDeleteFilter={deleteSavedFilter}
          cities={cities}
          neighborhoods={getNeighborhoodsByCity(filters.city !== 'all' ? filters.city : undefined)}
        />

        {/* Grid de Perfis */}
        <div key={category} className="mt-6 animate-fade-in">
          {currentProfiles.length === 0 ? (
            isLoading ? null : (
              <EmptyState
                type="no-results"
                category={category}
                location={state.name}
                onClearFilters={() => {
                  resetFilters();
                  setSearchParams({});
                  setSelectedCategory("Todos");
                }}
                onExploreNearby={() => navigate('/')}
              />
            )
          ) : (
              <>
                {/* Contador de Resultados */}
                <div className="flex items-center justify-between mb-4 text-sm text-muted-foreground">
                  <p>
                    Mostrando <span className="font-semibold text-foreground">
                      {currentProfiles.length}
                    </span> de <span className="font-semibold text-foreground">
                      {filteredProfiles.length}
                    </span> perfis
                  </p>
                </div>
              
                <div className={viewMode === 'grid' 
                  ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                  : "grid grid-cols-1 lg:grid-cols-2 gap-6"
                }>
                {isLoading ? (
                  // Skeleton loading
                  Array.from({ length: BATCH_SIZE }).map((_, idx) => (
                  viewMode === 'grid' ? (
                    <ProfileCardSkeleton key={`skeleton-${idx}`} />
                  ) : (
                    <ProfileListItemSkeleton key={`skeleton-${idx}`} />
                  )
                ))
              ) : (
                currentProfiles.map((profile) => {
                  const transformed = transformProfile(profile);
                  return viewMode === 'grid' ? (
                    <ProfileCard 
                      key={profile.id} 
                      {...transformed}
                      state={state.code.toLowerCase()}
                      city={profile.city}
                      category={profile.category}
                    />
                  ) : (
                    <ProfileListItem 
                      key={profile.id} 
                      {...transformed}
                      state={state.code.toLowerCase()}
                      city={profile.city}
                      category={profile.category}
                    />
                  );
                })
              )}
              </div>

              {/* Loading indicator para scroll infinito */}
              {currentProfiles.length > 0 && (isLoadingMore || hasMore) && (
                <div className="flex justify-center py-8">
                  {isLoadingMore ? (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                      <span>Carregando mais perfis...</span>
                    </div>
                  ) : hasMore && (
                    <p className="text-sm text-muted-foreground">Role para carregar mais perfis</p>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Estados Vizinhos */}
        <NeighboringStates 
          currentStateCode={state.code}
          category={category}
        />
      </main>

      <InternalNavigation 
        state={state.code.toLowerCase()} 
        city={city?.slug} 
        category={category}
        neighborhoodCounts={neighborhoodCounts}
      />

      <Footer />
    </div>
  );
};

export default StateView;
