import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Heart, ArrowLeft } from "lucide-react";
import Header from "@/components/Header";
import ProfileCard from "@/components/ProfileCard";
import ProfileListItem from "@/components/ProfileListItem";
import { Button } from "@/components/ui/button";
import { useFavorites } from "@/hooks/useFavorites";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

const BATCH_SIZE = 12;

interface SupabaseProfile {
  id: string;
  name: string;
  age: number;
  photos: string[];
  state: string;
  city: string;
  category: string;
  pricing: any;
  verified: boolean;
  description: string;
  services: string[];
  featured: boolean;
  created_at: string;
}

const Favorites = () => {
  const navigate = useNavigate();
  const [displayedCount, setDisplayedCount] = useState(BATCH_SIZE);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const { favorites } = useFavorites();
  const [favoriteProfiles, setFavoriteProfiles] = useState<SupabaseProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(() => {
    const saved = localStorage.getItem('viewMode');
    return (saved === 'grid' || saved === 'list') ? saved : 'list';
  });

  useEffect(() => {
    const fetchFavoriteProfiles = async () => {
      if (favorites.length === 0) {
        setFavoriteProfiles([]);
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('model_profiles')
          .select('id, name, age, photos, state, city, category, pricing, verified, description, services, featured, created_at')
          .in('id', favorites)
          .eq('is_active', true);

        if (error) throw error;
        setFavoriteProfiles(data || []);
      } catch (error) {
        console.error('Erro ao buscar favoritos:', error);
        setFavoriteProfiles([]);
      } finally {
        setLoading(false);
      }
    };

    fetchFavoriteProfiles();
  }, [favorites]);

  // Scroll infinito
  const displayedProfiles = favoriteProfiles.slice(0, displayedCount);
  const hasMore = displayedCount < favoriteProfiles.length;

  // Reset displayedCount quando favoritos mudam
  useEffect(() => {
    setDisplayedCount(BATCH_SIZE);
  }, [favorites]);

  // Infinite scroll listener
  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.innerHeight + window.scrollY;
      const threshold = document.documentElement.scrollHeight - 500;
      
      if (scrolled >= threshold && !isLoadingMore && hasMore) {
        setIsLoadingMore(true);
        setTimeout(() => {
          setDisplayedCount(prev => prev + BATCH_SIZE);
          setIsLoadingMore(false);
        }, 300);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoadingMore, hasMore]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="mb-4 -ml-2 hover:bg-secondary"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <div className="flex items-center gap-3 mb-2">
            <Heart className="h-8 w-8 fill-primary text-primary" />
            <h1 className="text-3xl font-bold">Meus Favoritos</h1>
          </div>
          <p className="text-muted-foreground">
            {displayedProfiles.length} {displayedProfiles.length === 1 ? 'perfil salvo' : 'perfis salvos'}
            {favoriteProfiles.length > displayedProfiles.length && ` (mostrando ${displayedProfiles.length} de ${favoriteProfiles.length})`}
          </p>
        </div>

        <div className="flex gap-2 mb-6">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            onClick={() => setViewMode('grid')}
            className={viewMode === 'grid' ? 'bg-gradient-to-r from-primary to-[hsl(320,75%,58%)]' : ''}
          >
            Grade
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            onClick={() => setViewMode('list')}
            className={viewMode === 'list' ? 'bg-gradient-to-r from-primary to-[hsl(320,75%,58%)]' : ''}
          >
            Lista
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-[3/4] w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : favoriteProfiles.length === 0 ? (
          <div className="text-center py-16">
            <Heart className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
            <h2 className="text-2xl font-semibold mb-2">Nenhum favorito ainda</h2>
            <p className="text-muted-foreground mb-6">
              Comece a adicionar perfis aos seus favoritos clicando no ícone de coração
            </p>
            <Button 
              onClick={() => navigate('/')}
              className="bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90"
            >
              Explorar Perfis
            </Button>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {displayedProfiles.map((profile) => {
              // Calcular se é novo (menos de 7 dias)
              const isNew = new Date(profile.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;
              // Simular online (pode ser implementado no futuro)
              const isOnline = false;
              // Mock rating (pode ser calculado das reviews no futuro)
              const rating = 4.5;

              return (
                <ProfileCard 
                  key={profile.id} 
                  id={profile.id}
                  slug={(profile as any).slug}
                  name={profile.name}
                  age={profile.age}
                  state={profile.state}
                  city={profile.city}
                  category={profile.category}
                  image={profile.photos[0] || '/placeholder.svg'}
                  location={`${profile.city}, ${profile.state}`}
                  description={profile.description || 'Descrição não disponível'}
                  tags={profile.services?.slice(0, 3) || []}
                  price={profile.pricing?.hourly || 0}
                  rating={rating}
                  verified={profile.verified}
                  featured={profile.featured}
                  isNew={isNew}
                  isOnline={isOnline}
                  isPremium={profile.featured}
                />
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {displayedProfiles.map((profile) => {
              const isNew = new Date(profile.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;
              const isOnline = false;
              const rating = 4.5;

              return (
                <ProfileListItem 
                  key={profile.id} 
                  id={profile.id}
                  name={profile.name}
                  age={profile.age}
                  state={profile.state}
                  city={profile.city}
                  category={profile.category}
                  image={profile.photos[0] || '/placeholder.svg'}
                  location={`${profile.city}, ${profile.state}`}
                  description={profile.description || 'Descrição não disponível'}
                  tags={profile.services?.slice(0, 3) || []}
                  price={profile.pricing?.hourly || 0}
                  rating={rating}
                  verified={profile.verified}
                  featured={profile.featured}
                  isNew={isNew}
                  isOnline={isOnline}
                  isPremium={profile.featured}
                />
              );
            })}
          </div>
        )}

        {/* Loading indicator para scroll infinito */}
        {!loading && displayedProfiles.length > 0 && (isLoadingMore || hasMore) && (
          <div className="flex justify-center py-8 mt-6">
            {isLoadingMore ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                <span>Carregando mais perfis...</span>
              </div>
            ) : hasMore && (
              <p className="text-sm text-muted-foreground">Role para carregar mais perfis</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default Favorites;
