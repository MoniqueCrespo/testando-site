import { useState, useEffect, useMemo } from "react";
import { useNavigate, useSearchParams, useParams } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HowItWorks from "@/components/HowItWorks";
import LocationSelector from "@/components/LocationSelector";
import FilterBar from "@/components/FilterBar";
import ProfileCard from "@/components/ProfileCard";
import ProfileListItem from "@/components/ProfileListItem";
import AdvancedFilters from "@/components/AdvancedFilters";
import SEOHead from "@/components/SEOHead";
import InternalNavigation from "@/components/InternalNavigation";
import { EmptyState } from "@/components/EmptyState";
import { StoriesBar } from "@/components/StoriesBar";
import { useFilters } from "@/hooks/useFilters";
import { useFavorites } from "@/hooks/useFavorites";
import { useLocation } from "@/hooks/useLocation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Loader2, Users, User, Sparkles, Heart, Flower2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { getStateBySlug, getStateByCode, getCityBySlug, getNeighborhoodBySlug } from "@/data/locations";
import type { CategoryType } from "@/types/location";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const Index = () => {
  const navigate = useNavigate();
  const { state: stateParam, locationOrCategory: locationParam, category: categoryParam } = useParams<{
    state?: string;
    locationOrCategory?: string;
    category?: string;
  }>();
  const [searchParams] = useSearchParams();
  
  // Resolver estado diretamente
  const state = stateParam ? (stateParam.length === 2 ? getStateByCode(stateParam.toUpperCase()) : getStateBySlug(stateParam)) : undefined;
  
  // TODOS os useState devem estar no topo
  const [profiles, setProfiles] = useState<Tables<'model_profiles'>[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);
  const [locationNotFound, setLocationNotFound] = useState(false);
  const [locationData, setLocationData] = useState<{
    type: 'city' | 'neighborhood';
    citySlug: string;
    neighborhood?: string;
  } | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(() => {
    const saved = localStorage.getItem('viewMode');
    return (saved === 'grid' || saved === 'list') ? saved : 'list';
  });
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  // Hooks customizados
  const { favorites } = useFavorites();
  const {
    filters,
    updateFilter,
    resetFilters,
    savedFilters,
    saveCurrentFilters,
    loadSavedFilter,
    deleteSavedFilter,
  } = useFilters();
  
  // Constantes derivadas - garantir que sempre há uma categoria válida
  const validCategories: CategoryType[] = ['mulheres', 'homens', 'trans', 'casais', 'massagistas'];
  const effectiveCategory: CategoryType = (categoryParam && validCategories.includes(categoryParam as CategoryType)) 
    ? (categoryParam as CategoryType)
    : 'mulheres';
  
  // Obter cidade - será preenchido via locationData do Supabase
  const [city, setCity] = useState<any>(null);
  
  // Transformar perfil do Supabase para formato do componente
  const transformProfile = (profile: Tables<'model_profiles'>) => ({
    ...profile,
    id: profile.id,
    slug: (profile as any).slug,
    location: `${profile.city}, ${profile.state}`,
    image: profile.photo_url || profile.photos?.[0] || '/placeholder.svg',
    rating: 4.5,
    tags: [],
    isNew: new Date(profile.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
    isOnline: Math.random() > 0.5,
    eyeColor: profile.eye_color,
    hairColor: profile.hair_color,
  });
  
  // TODOS os useMemo devem estar antes dos returns condicionais
  const filteredProfiles = useMemo(() => {
    return profiles.filter(profile => {
      if (filters.searchName.trim()) {
        const searchTerm = filters.searchName.toLowerCase().trim();
        const profileName = profile.name.toLowerCase();
        if (!profileName.includes(searchTerm)) return false;
      }

      if (profile.age < filters.ageRange[0] || profile.age > filters.ageRange[1]) return false;
      if (profile.price < filters.priceRange[0] || profile.price > filters.priceRange[1]) return false;
      if (profile.height && (profile.height < filters.height[0] || profile.height > filters.height[1])) return false;
      if (profile.weight && (profile.weight < filters.weight[0] || profile.weight > filters.weight[1])) return false;
      
      if (filters.eyeColor.length > 0 && profile.eye_color && !filters.eyeColor.includes(profile.eye_color)) return false;
      if (filters.hairColor.length > 0 && profile.hair_color && !filters.hairColor.includes(profile.hair_color)) return false;
      if (filters.services.length > 0 && profile.services && !filters.services.some(s => profile.services.includes(s))) return false;
      if (filters.availability.length > 0 && profile.availability && !filters.availability.some(a => profile.availability.includes(a))) return false;
      if (filters.neighborhoods.length > 0 && profile.neighborhoods && !filters.neighborhoods.some(n => profile.neighborhoods.includes(n))) return false;

      if (selectedCategory !== 'Todos') {
        if (selectedCategory === 'Destaque' && !profile.featured) return false;
        if (selectedCategory === 'Verificados' && !profile.verified) return false;
      }

      if (showOnlyFavorites && !favorites.includes(String(profile.id))) {
        return false;
      }

      return true;
    });
  }, [profiles, filters, selectedCategory, showOnlyFavorites, favorites]);

  const featuredProfiles = useMemo(() => 
    filteredProfiles.filter(p => p.featured), 
    [filteredProfiles]
  );
  
  const regularProfiles = useMemo(() => 
    filteredProfiles.filter(p => !p.featured), 
    [filteredProfiles]
  );

  const categoryNames: Record<CategoryType, string> = {
    mulheres: 'Acompanhantes',
    homens: 'Homens',
    trans: 'Trans',
    casais: 'Casais',
    massagistas: 'Massagistas',
  };
  
  // Calcular contagem de perfis por categoria
  const getCategoryCount = (cat: CategoryType) => {
    return profiles.filter(p => p.category === cat).length;
  };
  
  const locationName = locationData?.type === 'neighborhood' && locationData.neighborhood
    ? locationData.neighborhood 
    : city?.name || '';

  const categoryName = categoryNames[effectiveCategory];
  const pageTitle = locationData?.type === 'neighborhood' && city
    ? `${categoryName} em ${locationName}, ${city.name} - ${state?.code} | Acompanhantes`
    : city ? `${categoryName} em ${city.name}, ${state?.code} | Acompanhantes` : '';
  const pageDescription = locationData?.type === 'neighborhood' && city
    ? `Encontre ${categoryName.toLowerCase()} no bairro ${locationName}, ${city.name}, ${state?.code}. ${filteredProfiles.length} ${filteredProfiles.length === 1 ? 'perfil verificado' : 'perfis verificados'} disponíveis nesta região.`
    : city ? `Encontre ${categoryName.toLowerCase()} em ${city.name}, ${state?.code}. ${filteredProfiles.length} ${filteredProfiles.length === 1 ? 'perfil verificado' : 'perfis verificados'} disponíveis. Anúncios atualizados e confiáveis.` : '';
  const pageKeywords = locationData?.type === 'neighborhood' && city
    ? `acompanhantes ${locationName}, ${categoryName.toLowerCase()} ${locationName}, ${categoryName.toLowerCase()} ${city.name}, escorts ${locationName}`
    : city ? `acompanhantes ${city.name}, ${categoryName.toLowerCase()} ${city.name}, ${categoryName.toLowerCase()} ${state?.name}, escorts ${city.name}` : '';
  const canonicalUrl = effectiveCategory === 'mulheres'
    ? `${window.location.origin}/acompanhantes/${state?.code.toLowerCase()}/${locationParam}`
    : `${window.location.origin}/acompanhantes/${state?.code.toLowerCase()}/${locationParam}/${effectiveCategory}`;
  
  // TODOS os useEffect devem estar antes dos returns condicionais
  useEffect(() => {
    const detectLocationType = async () => {
      setIsLoadingLocation(true);
      setLocationNotFound(false);
      setLocationData(null);
      setCity(null);
      
      if (!stateParam || !locationParam) {
        setIsLoadingLocation(false);
        setLocationNotFound(true);
        return;
      }
      
      // Detectar se stateParam é sigla (2 chars) ou slug completo
      const stateObj = stateParam.length === 2 
        ? getStateByCode(stateParam.toUpperCase()) 
        : getStateBySlug(stateParam);
        
      if (!stateObj) {
        console.log('[Index] Estado não encontrado:', stateParam);
        setIsLoadingLocation(false);
        setLocationNotFound(true);
        return;
      }
      
      // QUERY DIRETA AO SUPABASE para obter dados da localização
      const { data: cityData, error } = await supabase
        .from('cities_seo')
        .select('*')
        .eq('city_slug', locationParam)
        .eq('state_code', stateObj.code.toUpperCase())
        .eq('is_active', true)
        .maybeSingle();
      
      if (error) {
        console.error('[Index] Erro ao buscar localização:', error);
        setIsLoadingLocation(false);
        setLocationNotFound(true);
        return;
      }
      
      if (!cityData) {
        console.log('[Index] Localização não encontrada no banco:', locationParam);
        setIsLoadingLocation(false);
        setLocationNotFound(true);
        return;
      }
      
      // Processar dados conforme estrutura do banco
      if (cityData.is_neighborhood && cityData.parent_city_slug) {
        // É um bairro
        setLocationData({
          type: 'neighborhood',
          citySlug: cityData.parent_city_slug,
          neighborhood: cityData.city_name
        });
        
        // Buscar dados da cidade pai para exibição
        const { data: parentCityData } = await supabase
          .from('cities_seo')
          .select('*')
          .eq('city_slug', cityData.parent_city_slug)
          .eq('state_code', stateObj.code.toUpperCase())
          .eq('is_active', true)
          .maybeSingle();
        
        if (parentCityData) {
          setCity({
            name: parentCityData.city_name,
            slug: parentCityData.city_slug,
            isNeighborhood: false
          });
        }
      } else {
        // É uma cidade
        setLocationData({
          type: 'city',
          citySlug: cityData.city_slug
        });
        
        setCity({
          name: cityData.city_name,
          slug: cityData.city_slug,
          isNeighborhood: false
        });
      }
      
      setIsLoadingLocation(false);
    };
    
    detectLocationType();
  }, [stateParam, locationParam]);
  
  useEffect(() => {
    if (!state || !locationData) return;
    
    const fetchProfiles = async () => {
      setIsLoading(true);
      
      let query = supabase
        .from('model_profiles')
        .select('*')
        .eq('state', state.code)
        .eq('category', effectiveCategory)
        .eq('is_active', true)
        .eq('moderation_status', 'approved');
      
      if (locationData.type === 'city') {
        query = query.eq('city', locationData.citySlug);
      } else if (locationData.type === 'neighborhood') {
        query = query
          .eq('city', locationData.citySlug)
          .contains('neighborhoods', [locationData.neighborhood]);
      }
      
      query = query
        .order('featured', { ascending: false })
        .order('created_at', { ascending: false });
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching profiles:', error);
      } else {
        setProfiles(data || []);
      }
      setIsLoading(false);
    };
    
    fetchProfiles();
  }, [state?.code, locationData, effectiveCategory]);
  
  useEffect(() => {
    if (!state || !locationData) return;
    
    const servicoParam = searchParams.get('servico');
    const bairroParam = searchParams.get('bairro');
    if (servicoParam || bairroParam) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [searchParams, state, locationData]);
  
  useEffect(() => {
    localStorage.setItem('viewMode', viewMode);
  }, [viewMode]);
  
  // Redirect to 404 if location was explicitly not found
  useEffect(() => {
    if (!isLoadingLocation && locationNotFound) {
      console.log('[Index] Redirecionando para 404 - localização não encontrada');
      navigate("/404", { replace: true });
    }
  }, [isLoadingLocation, locationNotFound, navigate]);
  
  // Returns condicionais APÓS todos os hooks
  if (isLoadingLocation) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-6">
          <div className="flex justify-center items-center min-h-[400px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  if (!state || !locationData || !city) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title={pageTitle}
        description={pageDescription}
        keywords={pageKeywords}
        canonical={canonicalUrl}
      />
      <Header />
      <LocationSelector />

      <main className="container mx-auto px-4">
        <section className="my-8">
          {state && city && (
            <>
              <StoriesBar 
                stateSlug={state.code}
                citySlug={city.slug}
                category={effectiveCategory}
              />
              
              <h1 className="text-3xl font-bold text-foreground mb-2">
                {categoryNames[effectiveCategory] || 'Acompanhantes'} em {locationName || city?.name || 'carregando...'}
                {locationData?.type === 'neighborhood' && city && `, ${city.name}`}
              </h1>
              <p className="text-muted-foreground mb-6">
                {filteredProfiles.length} {filteredProfiles.length === 1 ? 'perfil encontrado' : 'perfis encontrados'}
              </p>
            </>
          )}

          {/* Botões de Categoria */}
          <div className="mb-4">
            <div className="bg-card border border-border rounded-lg p-1.5">
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
                <Button
                  variant={effectiveCategory === 'mulheres' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const newUrl = locationData?.type === 'neighborhood'
                      ? `/acompanhantes/${state.code.toLowerCase()}/${locationParam}`
                      : `/acompanhantes/${state.code.toLowerCase()}/${locationParam}`;
                    navigate(newUrl);
                  }}
                  className={`gap-2 min-w-[140px] ${
                    effectiveCategory === 'mulheres' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                  <Users className="w-4 h-4" />
                  Mulheres
                  <Badge variant="secondary" className="ml-auto">
                    {getCategoryCount('mulheres')}
                  </Badge>
                </Button>
                
                <Button
                  variant={effectiveCategory === 'homens' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const newUrl = locationData?.type === 'neighborhood'
                      ? `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/homens`
                      : `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/homens`;
                    navigate(newUrl);
                  }}
                  className={`gap-2 min-w-[140px] ${
                    effectiveCategory === 'homens' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                  <User className="w-4 h-4" />
                  Homens
                  <Badge variant="secondary" className="ml-auto">
                    {getCategoryCount('homens')}
                  </Badge>
                </Button>
                
                <Button
                  variant={effectiveCategory === 'trans' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const newUrl = locationData?.type === 'neighborhood'
                      ? `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/trans`
                      : `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/trans`;
                    navigate(newUrl);
                  }}
                  className={`gap-2 min-w-[140px] ${
                    effectiveCategory === 'trans' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  Trans
                  <Badge variant="secondary" className="ml-auto">
                    {getCategoryCount('trans')}
                  </Badge>
                </Button>
                
                <Button
                  variant={effectiveCategory === 'casais' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const newUrl = locationData?.type === 'neighborhood'
                      ? `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/casais`
                      : `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/casais`;
                    navigate(newUrl);
                  }}
                  className={`gap-2 min-w-[140px] ${
                    effectiveCategory === 'casais' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                  <Heart className="w-4 h-4" />
                  Casais
                  <Badge variant="secondary" className="ml-auto">
                    {getCategoryCount('casais')}
                  </Badge>
                </Button>
                
                <Button
                  variant={effectiveCategory === 'massagistas' ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    const newUrl = locationData?.type === 'neighborhood'
                      ? `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/massagistas`
                      : `/acompanhantes/${state.code.toLowerCase()}/${locationParam}/massagistas`;
                    navigate(newUrl);
                  }}
                  className={`gap-2 min-w-[140px] ${
                    effectiveCategory === 'massagistas' 
                      ? "bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90" 
                      : "hover:bg-secondary"
                  }`}
                >
                  <Flower2 className="w-4 h-4" />
                  Massagistas
                  <Badge variant="secondary" className="ml-auto">
                    {getCategoryCount('massagistas')}
                  </Badge>
                </Button>
              </div>
            </div>
          </div>

          <FilterBar
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            onFiltersClick={() => setFiltersOpen(!filtersOpen)}
            showOnlyFavorites={showOnlyFavorites}
            onToggleFavorites={() => setShowOnlyFavorites(!showOnlyFavorites)}
          />

          <AdvancedFilters
            open={filtersOpen}
            onOpenChange={setFiltersOpen}
            filters={filters}
            onFilterChange={updateFilter}
            onReset={resetFilters}
            savedFilters={savedFilters}
            onSaveFilters={saveCurrentFilters}
            onLoadFilter={loadSavedFilter}
            onDeleteFilter={deleteSavedFilter}
          />

          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">Carregando perfis...</p>
            </div>
          ) : filteredProfiles.length === 0 ? (
            <EmptyState
              type="no-results"
              category={effectiveCategory}
              location={`${city?.name}, ${state?.name}`}
              onClearFilters={resetFilters}
              onExploreNearby={() => navigate(`/acompanhantes/${state?.code.toLowerCase()}`)}
            />
          ) : (
            <>
              {featuredProfiles.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-xl font-semibold text-foreground mb-4">
                    Anúncios em Destaque
                  </h2>
                  <Carousel
                    opts={{
                      align: "start",
                      loop: true,
                    }}
                    className="w-full"
                  >
                    <CarouselContent>
                      {featuredProfiles.map((profile) => {
                        const transformed = transformProfile(profile);
                        return (
                          <CarouselItem key={profile.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                            <ProfileCard 
                              {...transformed}
                              state={state.code}
                              city={city.slug}
                              category={profile.category}
                            />
                          </CarouselItem>
                        );
                      })}
                    </CarouselContent>
                    <CarouselPrevious />
                    <CarouselNext />
                  </Carousel>
                </div>
              )}

        {regularProfiles.length > 0 && (
          <div>
            {featuredProfiles.length > 0 && (
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Todos os Anúncios
              </h2>
            )}
            <article className={viewMode === 'grid' 
              ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-8"
              : "grid grid-cols-1 lg:grid-cols-2 gap-4 mt-8"
            }>
              {regularProfiles.map((profile) => {
                const transformed = transformProfile(profile);
                return viewMode === 'grid' ? (
                  <ProfileCard 
                    key={profile.id}
                    {...transformed}
                    state={state.code}
                    city={city.slug}
                    category={profile.category}
                  />
                ) : (
                  <ProfileListItem 
                    key={profile.id}
                    {...transformed}
                    state={state.code}
                    city={city.slug}
                    category={profile.category}
                  />
                );
              })}
            </article>
          </div>
        )}
            </>
          )}
        </section>
      </main>
      
      <HowItWorks />
      
      {state && city && (
        <InternalNavigation 
          state={state.code.toLowerCase()} 
          city={city.isNeighborhood && city.parentCitySlug ? city.parentCitySlug : city.slug} 
          category={effectiveCategory} 
        />
      )}
      
      <Footer />
    </div>
  );
};

export default Index;
