import { useEffect, useState } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { getStateByCode, getStateBySlug } from '@/data/locations';
import { supabase } from '@/integrations/supabase/client';
import CityView from './CityView';
import Index from './Index';
import ProfileDetail from './ProfileDetail';
import { Loader2 } from 'lucide-react';
import { CategoryType } from '@/types/location';

/**
 * LocationRouter - Roteador hierárquico para localizações
 * Detecta se é cidade ou bairro e renderiza o componente apropriado
 */
const LocationRouter = () => {
  const { state: stateParam, locationOrCategory, category: categoryParam, profileSlug } = useParams<{
    state: string;
    locationOrCategory: string;
    category?: string;
    profileSlug?: string;
  }>();
  
  // locationOrCategory pode vir como :locationOrCategory (rota de 2 níveis) 
  // ou como :category (rota de 3 níveis onde locationOrCategory é a cidade/bairro)
  const location = locationOrCategory;
  
  const [redirectTo, setRedirectTo] = useState<string | null>(null);
  const [component, setComponent] = useState<'city' | 'index' | 'profile' | null>(null);
  const [locationData, setLocationData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const detectLocation = async () => {
      if (!stateParam || !location) {
        setRedirectTo('/404');
        setIsLoading(false);
        return;
      }

      // Resolver estado (aceitar sigla ou slug)
      let state = getStateByCode(stateParam);
      if (!state) {
        state = getStateBySlug(stateParam);
      }
      
      if (!state) {
        setRedirectTo('/404');
        setIsLoading(false);
        return;
      }

      // Redirecionar slug completo para sigla
      if (stateParam.length > 2) {
        const url = categoryParam 
          ? `/acompanhantes/${state.code.toLowerCase()}/${location}/${categoryParam}`
          : `/acompanhantes/${state.code.toLowerCase()}/${location}`;
        setRedirectTo(url);
        setIsLoading(false);
        return;
      }

      // Buscar location no banco
      const { data: cityData } = await supabase
        .from('cities_seo')
        .select('*')
        .eq('city_slug', location)
        .eq('state_code', state.code)
        .eq('is_active', true)
        .maybeSingle();

      if (!cityData) {
        setRedirectTo('/404');
        setIsLoading(false);
        return;
      }

      const isNeighborhood = cityData.is_neighborhood || false;
      const validCategories: CategoryType[] = ['mulheres', 'homens', 'trans', 'casais', 'massagistas'];
      
      // Se temos profileSlug (4º nível), verificar se é um perfil válido
      if (profileSlug) {
        const { data: profileData } = await supabase
          .from('model_profiles')
          .select('id, slug')
          .eq('slug', profileSlug)
          .eq('is_active', true)
          .maybeSingle();
        
        if (profileData) {
          setComponent('profile');
          setIsLoading(false);
          return;
        }
        
        // profileSlug inválido - 404
        setRedirectTo('/404');
        setIsLoading(false);
        return;
      }
      
      // Se categoryParam existe mas NÃO é uma categoria válida, pode ser um slug de perfil
      if (categoryParam && !validCategories.includes(categoryParam as CategoryType)) {
        const { data: profileData } = await supabase
          .from('model_profiles')
          .select('id, slug')
          .eq('slug', categoryParam)
          .eq('is_active', true)
          .maybeSingle();
        
        if (profileData) {
          // É um perfil - renderizar ProfileDetail
          setComponent('profile');
          setIsLoading(false);
          return;
        }
        
        // Não é categoria nem perfil - 404
        setRedirectTo('/404');
        setIsLoading(false);
        return;
      }
      
      const category = (categoryParam && validCategories.includes(categoryParam as CategoryType))
        ? categoryParam as CategoryType
        : 'mulheres';

      setLocationData({
        state,
        city: {
          id: cityData.id,
          name: cityData.city_name,
          slug: cityData.city_slug,
          state: state.code,
          isNeighborhood,
          parentCitySlug: cityData.parent_city_slug
        },
        category
      });

      // Decisão de renderização:
      // - Cidade SEM categoria → CityView (grid de categorias)
      // - Cidade COM categoria → Index (listagem de perfis)
      // - Bairro (com ou sem categoria) → Index (listagem de perfis)
      if (!isNeighborhood && !categoryParam) {
        setComponent('city');
      } else {
        setComponent('index');
      }

      setIsLoading(false);
    };

    detectLocation();
  }, [stateParam, location, categoryParam]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (redirectTo) {
    return <Navigate to={redirectTo} replace />;
  }

  if (component === 'profile') {
    return <ProfileDetail />;
  }

  if (component === 'city' && locationData) {
    return <CityView state={locationData.state} city={locationData.city} />;
  }

  if (component === 'index') {
    return <Index />;
  }

  return null;
};

export default LocationRouter;
