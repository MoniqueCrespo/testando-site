import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { MapPin } from "lucide-react";

import { getNeighboringStates } from "@/data/locations";
import { supabase } from "@/integrations/supabase/client";
import type { BrazilState } from "@/types/location";
import type { CategoryType } from "@/types/location";

interface NeighboringStatesProps {
  currentStateCode: string;
  category: CategoryType;
}

export const NeighboringStates = ({ currentStateCode, category }: NeighboringStatesProps) => {
  const [statesWithCounts, setStatesWithCounts] = useState<Array<{
    state: BrazilState;
    count: number;
  }>>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCounts = async () => {
      setIsLoading(true);
      const neighbors = getNeighboringStates(currentStateCode);
      
      const countsPromises = neighbors.slice(0, 5).map(async (state) => {
        const { count } = await supabase
          .from('model_profiles')
          .select('*', { count: 'exact', head: true })
          .eq('state', state.slug)
          .eq('category', category)
          .eq('is_active', true);
        
        return { state, count: count || 0 };
      });
      
      const results = await Promise.all(countsPromises);
      // Filtrar estados com perfis mantendo ordem geográfica
      const filtered = results.filter(r => r.count > 0);
      
      setStatesWithCounts(filtered);
      setIsLoading(false);
    };
    
    fetchCounts();
  }, [currentStateCode, category]);

  if (isLoading || statesWithCounts.length === 0) return null;

  return (
    <section className="mt-12 mb-8">
      <h2 className="text-2xl font-bold mb-2 text-foreground flex items-center gap-2">
        <MapPin className="h-5 w-5 text-primary" />
        Estados Vizinhos
      </h2>
      <p className="text-sm text-muted-foreground mb-4">
        Explore perfis em estados próximos geograficamente
      </p>
      
      <div className="flex flex-wrap gap-2">
        {statesWithCounts.map(({ state, count }) => (
          <Link
            key={state.code}
            to={category === 'mulheres' 
              ? `/acompanhantes/${state.code.toLowerCase()}` 
              : `/acompanhantes/${state.code.toLowerCase()}/${category}`
            }
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-muted text-foreground rounded-full text-sm transition-all duration-200 hover:bg-primary/10 hover:text-primary cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>{state.name}</span>
            <span className="text-xs text-muted-foreground/70">
              ({count})
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
};
