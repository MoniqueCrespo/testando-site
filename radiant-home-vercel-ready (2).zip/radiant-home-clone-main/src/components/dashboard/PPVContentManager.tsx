import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, DollarSign, Eye, ShoppingCart, Image as ImageIcon, Video } from "lucide-react";
import { useDropzone } from "react-dropzone";
import imageCompression from "browser-image-compression";
import { OptimizedImage } from "@/components/OptimizedImage";

interface PPVContentManagerProps {
  profileId: string;
}

interface PPVContent {
  id: string;
  title: string;
  description: string;
  price: number;
  media_type: string;
  media_url: string;
  view_count: number;
  purchase_count: number;
}

export const PPVContentManager = ({ profileId }: PPVContentManagerProps) => {
  const [content, setContent] = useState<PPVContent[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchContent();
  }, [profileId]);

  const fetchContent = async () => {
    const { data } = await supabase
      .from('ppv_content')
      .select('*')
      .eq('profile_id', profileId)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    
    if (!data) {
      setContent([]);
      return;
    }

    // Generate signed URLs for media
    const enrichedContent = await Promise.all(
      data.map(async (item) => {
        let signedUrl = item.media_url;
        
        // Extract file path from the stored URL
        const urlParts = item.media_url.split("/exclusive-content/");
        if (urlParts.length > 1) {
          const filePath = urlParts[1];
          
          // Generate signed URL (valid for 1 hour)
          const { data: signedData } = await supabase.storage
            .from("exclusive-content")
            .createSignedUrl(filePath, 3600);
          
          if (signedData?.signedUrl) {
            signedUrl = signedData.signedUrl;
          }
        }

        return {
          ...item,
          media_url: signedUrl,
        };
      })
    );
    
    setContent(enrichedContent);
  };

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');

    if (!isImage && !isVideo) {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione uma imagem ou vídeo",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    setPreview(URL.createObjectURL(file));
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png', '.webp'],
      'video/*': ['.mp4', '.mov'],
    },
    maxFiles: 1,
  });

  const handleUpload = async () => {
    if (!selectedFile || !formData.title || !formData.price) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha título, preço e selecione um arquivo",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    try {
      let fileToUpload = selectedFile;
      const isImage = selectedFile.type.startsWith('image/');

      if (isImage && selectedFile.size > 2 * 1024 * 1024) {
        fileToUpload = await imageCompression(selectedFile, {
          maxSizeMB: 2,
          maxWidthOrHeight: 1920,
          useWebWorker: true,
        });
      }

      const fileExt = fileToUpload.name.split('.').pop();
      const fileName = `${profileId}/ppv/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('exclusive-content')
        .upload(fileName, fileToUpload);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('exclusive-content')
        .getPublicUrl(fileName);

      const { error: insertError } = await supabase
        .from('ppv_content')
        .insert({
          profile_id: profileId,
          media_type: isImage ? 'image' : 'video',
          media_url: publicUrl,
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
        });

      if (insertError) throw insertError;

      toast({ title: "Conteúdo PPV publicado com sucesso!" });
      setIsDialogOpen(false);
      resetForm();
      fetchContent();
    } catch (error) {
      console.error('Error uploading PPV content:', error);
      toast({
        title: "Erro",
        description: "Não foi possível publicar o conteúdo",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setPreview(null);
    setFormData({
      title: "",
      description: "",
      price: "",
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Conteúdo PPV (Pay-Per-View)</h3>
          <p className="text-sm text-muted-foreground">Venda conteúdo individual além da assinatura</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Novo PPV
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Publicar Conteúdo PPV</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {!selectedFile ? (
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                  }`}
                >
                  <input {...getInputProps()} />
                  <p>Arraste uma foto ou vídeo exclusivo</p>
                  <p className="text-sm text-muted-foreground mt-2">Máximo 100MB</p>
                </div>
              ) : (
                <Card>
                  <CardContent className="p-4">
                    <div className="relative rounded-lg overflow-hidden bg-muted aspect-video max-h-[300px] flex items-center justify-center">
                      {selectedFile.type.startsWith('image/') ? (
                        <img src={preview!} alt="Preview" className="max-w-full max-h-[300px] object-contain" />
                      ) : (
                        <video src={preview!} controls className="max-w-full max-h-[300px] object-contain" />
                      )}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedFile(null);
                        setPreview(null);
                      }}
                      className="mt-2"
                    >
                      Trocar arquivo
                    </Button>
                  </CardContent>
                </Card>
              )}

              <div>
                <Label htmlFor="title">Título *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ex: Ensaio Fotográfico Exclusivo"
                />
              </div>

              <div>
                <Label htmlFor="price">Preço (R$) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="19.90"
                />
              </div>

              <div>
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descreva o que está incluído neste conteúdo..."
                  rows={3}
                />
              </div>

              <Button
                onClick={handleUpload}
                disabled={!selectedFile || uploading || !formData.title || !formData.price}
                className="w-full"
              >
                {uploading ? 'Publicando...' : 'Publicar PPV'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {content.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            Você ainda não publicou nenhum conteúdo PPV
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {content.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <CardContent className="p-0">
                {/* Thumbnail */}
                <div className="relative aspect-square bg-muted">
                  {item.media_type === "image" ? (
                    <OptimizedImage
                      src={item.media_url}
                      alt={item.title}
                      className="w-full h-full object-cover"
                      priority={false}
                    />
                  ) : (
                    <div className="relative w-full h-full">
                      <video
                        src={item.media_url}
                        className="w-full h-full object-cover"
                      />
                      <Video className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 text-white opacity-80" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-4 space-y-3">
                  <h3 className="font-semibold line-clamp-1">{item.title}</h3>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4 text-primary" />
                      <span className="font-bold text-primary">R$ {item.price.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {item.view_count}
                      </div>
                      <div className="flex items-center gap-1">
                        <ShoppingCart className="w-3 h-3" />
                        {item.purchase_count}
                      </div>
                    </div>
                  </div>
                  
                  {item.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {item.description}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
