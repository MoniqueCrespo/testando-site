import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { initializeCities } from "./data/locations";

// Inicializar cache de cidades ao carregar a aplicação
initializeCities();

createRoot(document.getElementById("root")!).render(<App />);
