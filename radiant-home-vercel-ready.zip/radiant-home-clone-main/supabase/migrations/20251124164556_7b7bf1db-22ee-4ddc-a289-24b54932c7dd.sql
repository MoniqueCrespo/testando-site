-- Add moderation fields to model_profiles
ALTER TABLE public.model_profiles 
ADD COLUMN IF NOT EXISTS moderation_status TEXT DEFAULT 'pending' CHECK (moderation_status IN ('pending', 'approved', 'rejected')),
ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
ADD COLUMN IF NOT EXISTS moderated_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS moderated_at TIMESTAMP WITH TIME ZONE;

-- Create index for faster queries on moderation status
CREATE INDEX IF NOT EXISTS idx_model_profiles_moderation_status ON public.model_profiles(moderation_status);

-- Update existing profiles to 'approved' status (retroactive)
UPDATE public.model_profiles 
SET moderation_status = 'approved' 
WHERE moderation_status = 'pending' AND is_active = true;

-- Create admin_login_attempts table for security logging
CREATE TABLE IF NOT EXISTS public.admin_login_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  email TEXT NOT NULL,
  success BOOLEAN NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on admin_login_attempts
ALTER TABLE public.admin_login_attempts ENABLE ROW LEVEL SECURITY;

-- Only admins can view login attempts
CREATE POLICY "Admins can view all login attempts"
ON public.admin_login_attempts
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_created_at ON public.admin_login_attempts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_email ON public.admin_login_attempts(email);

-- Update RLS policies for model_profiles to consider moderation
DROP POLICY IF EXISTS "Models can view all active profiles" ON public.model_profiles;
CREATE POLICY "Models can view approved active profiles or their own"
ON public.model_profiles
FOR SELECT
USING (
  (is_active = true AND moderation_status = 'approved') 
  OR (auth.uid() = user_id AND has_role(auth.uid(), 'model'))
);

-- Admins can view all profiles regardless of moderation status
CREATE POLICY "Admins can view all profiles"
ON public.model_profiles
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Admins can update moderation fields
CREATE POLICY "Admins can update all profiles"
ON public.model_profiles
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Update existing policy for visitors
DROP POLICY IF EXISTS "Qualquer pessoa pode visualizar perfis ativos" ON public.model_profiles;
CREATE POLICY "Anyone can view approved active profiles"
ON public.model_profiles
FOR SELECT
USING (is_active = true AND moderation_status = 'approved');