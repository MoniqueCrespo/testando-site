-- Corrigir funções com search_path mutável
-- Recriar função generate_profile_slug com search_path seguro
CREATE OR REPLACE FUNCTION generate_profile_slug(profile_name TEXT, profile_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_slug TEXT;
  final_slug TEXT;
  counter INTEGER := 0;
BEGIN
  -- Normalizar nome para slug (remover acentos, espaços, caracteres especiais)
  base_slug := lower(regexp_replace(
    unaccent(profile_name),
    '[^a-z0-9]+', '-', 'g'
  ));
  -- Remover hífens no início e fim
  base_slug := trim(both '-' from base_slug);
  
  -- Se o slug ficou vazio, usar um padrão genérico
  IF base_slug = '' THEN
    base_slug := 'perfil';
  END IF;
  
  final_slug := base_slug;
  
  -- Verificar unicidade e adicionar contador se necessário
  WHILE EXISTS (SELECT 1 FROM model_profiles WHERE slug = final_slug AND id != profile_id) LOOP
    counter := counter + 1;
    final_slug := base_slug || '-' || counter;
  END LOOP;
  
  RETURN final_slug;
END;
$$;

-- Recriar função auto_generate_profile_slug com search_path seguro
CREATE OR REPLACE FUNCTION auto_generate_profile_slug()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Se slug não foi fornecido ou está vazio, gerar automaticamente
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_profile_slug(NEW.name, NEW.id);
  END IF;
  RETURN NEW;
END;
$$;