-- Criar tabela de bairros (neighborhoods) com relacionamento com cidades
CREATE TABLE IF NOT EXISTS public.neighborhoods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  city_slug TEXT NOT NULL,
  state_code TEXT NOT NULL,
  neighborhood_name TEXT NOT NULL,
  neighborhood_slug TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(city_slug, state_code, neighborhood_slug)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_neighborhoods_city ON public.neighborhoods(city_slug, state_code);
CREATE INDEX IF NOT EXISTS idx_neighborhoods_active ON public.neighborhoods(is_active);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_neighborhoods_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER update_neighborhoods_updated_at
  BEFORE UPDATE ON public.neighborhoods
  FOR EACH ROW
  EXECUTE FUNCTION update_neighborhoods_updated_at();

-- RLS Policies
ALTER TABLE public.neighborhoods ENABLE ROW LEVEL SECURITY;

-- Admins podem gerenciar bairros
CREATE POLICY "Admins podem gerenciar bairros"
  ON public.neighborhoods
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Todos podem ver bairros ativos
CREATE POLICY "Todos podem ver bairros ativos"
  ON public.neighborhoods
  FOR SELECT
  USING (is_active = true);

-- Inserir bairros do Rio de Janeiro como exemplo
INSERT INTO public.neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug) VALUES
('rio-de-janeiro', 'RJ', 'Copacabana', 'copacabana'),
('rio-de-janeiro', 'RJ', 'Ipanema', 'ipanema'),
('rio-de-janeiro', 'RJ', 'Leblon', 'leblon'),
('rio-de-janeiro', 'RJ', 'Barra da Tijuca', 'barra-da-tijuca'),
('rio-de-janeiro', 'RJ', 'Botafogo', 'botafogo'),
('rio-de-janeiro', 'RJ', 'Flamengo', 'flamengo'),
('rio-de-janeiro', 'RJ', 'Centro', 'centro'),
('rio-de-janeiro', 'RJ', 'Tijuca', 'tijuca'),
('rio-de-janeiro', 'RJ', 'Recreio dos Bandeirantes', 'recreio-dos-bandeirantes'),
('rio-de-janeiro', 'RJ', 'Jacarepaguá', 'jacarepagua');

-- Inserir bairros de São Paulo como exemplo
INSERT INTO public.neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug) VALUES
('sao-paulo', 'SP', 'Jardins', 'jardins'),
('sao-paulo', 'SP', 'Moema', 'moema'),
('sao-paulo', 'SP', 'Vila Olímpia', 'vila-olimpia'),
('sao-paulo', 'SP', 'Pinheiros', 'pinheiros'),
('sao-paulo', 'SP', 'Itaim Bibi', 'itaim-bibi'),
('sao-paulo', 'SP', 'Centro', 'centro'),
('sao-paulo', 'SP', 'Vila Mariana', 'vila-mariana'),
('sao-paulo', 'SP', 'Brooklin', 'brooklin'),
('sao-paulo', 'SP', 'Morumbi', 'morumbi'),
('sao-paulo', 'SP', 'Perdizes', 'perdizes')
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;