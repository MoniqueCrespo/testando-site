-- Create profile_stories table
CREATE TABLE IF NOT EXISTS public.profile_stories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  media_url TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('image', 'video')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '24 hours') NOT NULL,
  view_count INTEGER DEFAULT 0 NOT NULL
);

-- Create story_views table
CREATE TABLE IF NOT EXISTS public.story_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id UUID NOT NULL REFERENCES public.profile_stories(id) ON DELETE CASCADE,
  viewer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  viewed_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE(story_id, viewer_id)
);

-- Enable RLS on profile_stories
ALTER TABLE public.profile_stories ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profile_stories
CREATE POLICY "Anyone can view active stories"
  ON public.profile_stories
  FOR SELECT
  USING (expires_at > now() AND EXISTS (
    SELECT 1 FROM public.model_profiles 
    WHERE id = profile_stories.profile_id 
    AND is_active = true 
    AND verified = true
  ));

CREATE POLICY "Models can create stories for their own verified profiles"
  ON public.profile_stories
  FOR INSERT
  WITH CHECK (
    auth.uid() IN (
      SELECT user_id FROM public.model_profiles 
      WHERE id = profile_id 
      AND verified = true
    )
  );

CREATE POLICY "Models can delete their own stories"
  ON public.profile_stories
  FOR DELETE
  USING (
    auth.uid() IN (
      SELECT user_id FROM public.model_profiles 
      WHERE id = profile_id
    )
  );

-- Enable RLS on story_views
ALTER TABLE public.story_views ENABLE ROW LEVEL SECURITY;

-- RLS Policies for story_views
CREATE POLICY "Anyone can insert story views"
  ON public.story_views
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view their own story views"
  ON public.story_views
  FOR SELECT
  USING (auth.uid() = viewer_id);

CREATE POLICY "Profile owners can view their stories' views"
  ON public.story_views
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profile_stories ps
      JOIN public.model_profiles mp ON ps.profile_id = mp.id
      WHERE ps.id = story_views.story_id
      AND mp.user_id = auth.uid()
    )
  );

-- Function to increment story views
CREATE OR REPLACE FUNCTION public.increment_story_views(story_uuid UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profile_stories
  SET view_count = view_count + 1
  WHERE id = story_uuid;
END;
$$;

-- Create story-media storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('story-media', 'story-media', true)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies for story-media bucket
CREATE POLICY "Public can view story media"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'story-media');

CREATE POLICY "Models can upload story media for their profiles"
  ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'story-media' 
    AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Models can delete their own story media"
  ON storage.objects
  FOR DELETE
  USING (
    bucket_id = 'story-media' 
    AND auth.uid() IS NOT NULL
  );

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_profile_stories_profile_id ON public.profile_stories(profile_id);
CREATE INDEX IF NOT EXISTS idx_profile_stories_expires_at ON public.profile_stories(expires_at);
CREATE INDEX IF NOT EXISTS idx_story_views_story_id ON public.story_views(story_id);