-- Tabela de comentários em conteúdo exclusivo
CREATE TABLE IF NOT EXISTS public.content_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL REFERENCES public.exclusive_content(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  comment_text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela de reações em conteúdo exclusivo
CREATE TABLE IF NOT EXISTS public.content_reactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL REFERENCES public.exclusive_content(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reaction_type TEXT NOT NULL CHECK (reaction_type IN ('like', 'love', 'fire', 'star')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(content_id, user_id, reaction_type)
);

-- Tabela de conteúdo PPV (pay-per-view)
CREATE TABLE IF NOT EXISTS public.ppv_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  media_type TEXT NOT NULL CHECK (media_type IN ('image', 'video')),
  media_url TEXT NOT NULL,
  thumbnail_url TEXT,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL CHECK (price > 0),
  is_active BOOLEAN DEFAULT true,
  view_count INTEGER DEFAULT 0,
  purchase_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela de compras de PPV
CREATE TABLE IF NOT EXISTS public.ppv_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ppv_content_id UUID NOT NULL REFERENCES public.ppv_content(id) ON DELETE CASCADE,
  price_paid NUMERIC NOT NULL,
  payment_id TEXT,
  payment_method TEXT DEFAULT 'mercadopago',
  purchased_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, ppv_content_id)
);

-- Tabela de configurações de proteção de conteúdo
CREATE TABLE IF NOT EXISTS public.content_protection_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL UNIQUE REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  watermark_enabled BOOLEAN DEFAULT true,
  watermark_text TEXT,
  watermark_opacity NUMERIC DEFAULT 0.5 CHECK (watermark_opacity >= 0 AND watermark_opacity <= 1),
  screenshot_detection_enabled BOOLEAN DEFAULT true,
  download_prevention_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela de logs de violação de proteção
CREATE TABLE IF NOT EXISTS public.content_violation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID NOT NULL REFERENCES public.exclusive_content(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  violation_type TEXT NOT NULL CHECK (violation_type IN ('screenshot', 'download_attempt', 'copy_attempt')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Criar índices
CREATE INDEX IF NOT EXISTS idx_content_comments_content ON public.content_comments(content_id);
CREATE INDEX IF NOT EXISTS idx_content_comments_user ON public.content_comments(user_id);
CREATE INDEX IF NOT EXISTS idx_content_reactions_content ON public.content_reactions(content_id);
CREATE INDEX IF NOT EXISTS idx_content_reactions_user ON public.content_reactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ppv_content_profile ON public.ppv_content(profile_id);
CREATE INDEX IF NOT EXISTS idx_ppv_purchases_user ON public.ppv_purchases(user_id);
CREATE INDEX IF NOT EXISTS idx_ppv_purchases_content ON public.ppv_purchases(ppv_content_id);
CREATE INDEX IF NOT EXISTS idx_violation_logs_content ON public.content_violation_logs(content_id);
CREATE INDEX IF NOT EXISTS idx_violation_logs_user ON public.content_violation_logs(user_id);

-- Triggers para updated_at
CREATE OR REPLACE FUNCTION public.update_content_comments_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_content_comments_updated_at
  BEFORE UPDATE ON public.content_comments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_content_comments_updated_at();

CREATE OR REPLACE FUNCTION public.update_content_protection_settings_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_content_protection_settings_updated_at
  BEFORE UPDATE ON public.content_protection_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_content_protection_settings_updated_at();

-- Enable RLS
ALTER TABLE public.content_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ppv_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ppv_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_protection_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_violation_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies para content_comments
CREATE POLICY "Subscribers can view comments on content they have access to"
  ON public.content_comments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.exclusive_content ec
      WHERE ec.id = content_comments.content_id
      AND (
        ec.is_preview = true OR
        EXISTS (
          SELECT 1 FROM public.content_subscriptions cs
          WHERE cs.subscriber_id = auth.uid()
          AND cs.profile_id = ec.profile_id
          AND cs.status = 'active'
          AND cs.end_date > now()
        )
      )
    )
  );

CREATE POLICY "Subscribers can create comments"
  ON public.content_comments FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM public.exclusive_content ec
      JOIN public.content_subscriptions cs ON cs.profile_id = ec.profile_id
      WHERE ec.id = content_comments.content_id
      AND cs.subscriber_id = auth.uid()
      AND cs.status = 'active'
      AND cs.end_date > now()
    )
  );

CREATE POLICY "Users can update own comments"
  ON public.content_comments FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
  ON public.content_comments FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all comments"
  ON public.content_comments FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies para content_reactions
CREATE POLICY "Anyone can view reactions count"
  ON public.content_reactions FOR SELECT
  USING (true);

CREATE POLICY "Subscribers can add reactions"
  ON public.content_reactions FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM public.exclusive_content ec
      JOIN public.content_subscriptions cs ON cs.profile_id = ec.profile_id
      WHERE ec.id = content_reactions.content_id
      AND cs.subscriber_id = auth.uid()
      AND cs.status = 'active'
      AND cs.end_date > now()
    )
  );

CREATE POLICY "Users can delete own reactions"
  ON public.content_reactions FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies para ppv_content
CREATE POLICY "Anyone can view active PPV content info"
  ON public.ppv_content FOR SELECT
  USING (is_active = true);

CREATE POLICY "Profile owners can manage their PPV content"
  ON public.ppv_content FOR ALL
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = ppv_content.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all PPV content"
  ON public.ppv_content FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies para ppv_purchases
CREATE POLICY "Users can view own PPV purchases"
  ON public.ppv_purchases FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own PPV purchases"
  ON public.ppv_purchases FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Profile owners can view their PPV sales"
  ON public.ppv_purchases FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.ppv_content pc
    JOIN public.model_profiles mp ON pc.profile_id = mp.id
    WHERE pc.id = ppv_purchases.ppv_content_id
    AND mp.user_id = auth.uid()
  ));

CREATE POLICY "Admins can view all PPV purchases"
  ON public.ppv_purchases FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies para content_protection_settings
CREATE POLICY "Profile owners can view own protection settings"
  ON public.content_protection_settings FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = content_protection_settings.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Profile owners can manage own protection settings"
  ON public.content_protection_settings FOR ALL
  USING (EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = content_protection_settings.profile_id
    AND model_profiles.user_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all protection settings"
  ON public.content_protection_settings FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies para content_violation_logs
CREATE POLICY "Profile owners can view violations on their content"
  ON public.content_violation_logs FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.exclusive_content ec
    JOIN public.model_profiles mp ON ec.profile_id = mp.id
    WHERE ec.id = content_violation_logs.content_id
    AND mp.user_id = auth.uid()
  ));

CREATE POLICY "System can insert violation logs"
  ON public.content_violation_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all violations"
  ON public.content_violation_logs FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Enable realtime for notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.content_comments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.content_reactions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.content_subscriptions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.exclusive_content;