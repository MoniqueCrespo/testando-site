-- Popular bairros das principais cidades turísticas do Rio de Janeiro
-- Esta migration adiciona bairros específicos das cidades mais visitadas do estado do RJ

-- Cabo Frio
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('cabo-frio', 'RJ', 'Ogiva', 'ogiva', true, true),
  ('cabo-frio', 'RJ', 'Braga', 'braga', true, true),
  ('cabo-frio', 'RJ', 'Peró', 'pero', true, true),
  ('cabo-frio', 'RJ', 'Jardim Excelsior', 'jardim-excelsior', true, true),
  ('cabo-frio', 'RJ', 'Passagem', 'passagem', true, true),
  ('cabo-frio', 'RJ', 'Centro', 'centro-cabo-frio', true, false),
  ('cabo-frio', 'RJ', 'Gamboa', 'gamboa', true, false),
  ('cabo-frio', 'RJ', 'São Cristóvão', 'sao-cristovao-cabo-frio', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Búzios
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('armacao-dos-buzios', 'RJ', 'Centro', 'centro-buzios', true, true),
  ('armacao-dos-buzios', 'RJ', 'Geribá', 'geriba', true, true),
  ('armacao-dos-buzios', 'RJ', 'Ferradura', 'ferradura', true, true),
  ('armacao-dos-buzios', 'RJ', 'João Fernandes', 'joao-fernandes', true, true),
  ('armacao-dos-buzios', 'RJ', 'Ossos', 'ossos', true, true),
  ('armacao-dos-buzios', 'RJ', 'Manguinhos', 'manguinhos-buzios', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Angra dos Reis
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('angra-dos-reis', 'RJ', 'Centro', 'centro-angra', true, true),
  ('angra-dos-reis', 'RJ', 'Frade', 'frade', true, true),
  ('angra-dos-reis', 'RJ', 'Praia do Bonfim', 'praia-do-bonfim', true, true),
  ('angra-dos-reis', 'RJ', 'Praia Grande', 'praia-grande-angra', true, true),
  ('angra-dos-reis', 'RJ', 'Jardim do Éden', 'jardim-do-eden', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Arraial do Cabo
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('arraial-do-cabo', 'RJ', 'Centro', 'centro-arraial', true, true),
  ('arraial-do-cabo', 'RJ', 'Praia dos Anjos', 'praia-dos-anjos', true, true),
  ('arraial-do-cabo', 'RJ', 'Prainha', 'prainha', true, true),
  ('arraial-do-cabo', 'RJ', 'Figueira', 'figueira', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Paraty
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('paraty', 'RJ', 'Centro Histórico', 'centro-historico-paraty', true, true),
  ('paraty', 'RJ', 'Caborê', 'cabore', true, true),
  ('paraty', 'RJ', 'Jabaquara', 'jabaquara', true, true),
  ('paraty', 'RJ', 'Portal das Artes', 'portal-das-artes', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Macaé
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('macae', 'RJ', 'Centro', 'centro-macae', true, true),
  ('macae', 'RJ', 'Cavaleiros', 'cavaleiros', true, true),
  ('macae', 'RJ', 'Imbetiba', 'imbetiba', true, true),
  ('macae', 'RJ', 'Praia Campista', 'praia-campista', true, true),
  ('macae', 'RJ', 'Lagomar', 'lagomar', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;

-- Campos dos Goytacazes
INSERT INTO neighborhoods (city_slug, state_code, neighborhood_name, neighborhood_slug, is_active, is_main)
VALUES
  ('campos-dos-goytacazes', 'RJ', 'Centro', 'centro-campos', true, true),
  ('campos-dos-goytacazes', 'RJ', 'Pelinca', 'pelinca', true, true),
  ('campos-dos-goytacazes', 'RJ', 'Guarus', 'guarus', true, true),
  ('campos-dos-goytacazes', 'RJ', 'Parque Tamandaré', 'parque-tamandare', true, true),
  ('campos-dos-goytacazes', 'RJ', 'Parque Aurora', 'parque-aurora', true, false),
  ('campos-dos-goytacazes', 'RJ', 'Parque Leopoldina', 'parque-leopoldina', true, false)
ON CONFLICT (city_slug, state_code, neighborhood_slug) DO NOTHING;