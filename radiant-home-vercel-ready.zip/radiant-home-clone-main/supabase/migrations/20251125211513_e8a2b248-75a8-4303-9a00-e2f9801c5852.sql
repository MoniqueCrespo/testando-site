-- Adicionar coluna para indicar se é bairro na tabela cities_seo
ALTER TABLE cities_seo 
ADD COLUMN is_neighborhood BOOLEAN DEFAULT false,
ADD COLUMN parent_city_slug TEXT;

-- Adicionar comentários
COMMENT ON COLUMN cities_seo.is_neighborhood IS 'Indica se este registro é um bairro (true) ou cidade (false)';
COMMENT ON COLUMN cities_seo.parent_city_slug IS 'Slug da cidade pai quando is_neighborhood=true';

-- Inserir bairros principais do Rio de Janeiro como opções de localização
INSERT INTO cities_seo (state_code, state_name, city_slug, city_name, is_neighborhood, parent_city_slug, is_active)
SELECT 
  'RJ' as state_code,
  'Rio de Janeiro' as state_name,
  neighborhood_slug as city_slug,
  neighborhood_name as city_name,
  true as is_neighborhood,
  'rio-de-janeiro' as parent_city_slug,
  true as is_active
FROM neighborhoods
WHERE state_code = 'RJ' AND city_slug = 'rio-de-janeiro' AND is_active = true
ON CONFLICT DO NOTHING;

-- Inserir bairros principais de São Paulo como opções de localização
INSERT INTO cities_seo (state_code, state_name, city_slug, city_name, is_neighborhood, parent_city_slug, is_active)
SELECT 
  'SP' as state_code,
  'São Paulo' as state_name,
  neighborhood_slug as city_slug,
  neighborhood_name as city_name,
  true as is_neighborhood,
  'sao-paulo' as parent_city_slug,
  true as is_active
FROM neighborhoods
WHERE state_code = 'SP' AND city_slug = 'sao-paulo' AND is_active = true
ON CONFLICT DO NOTHING;