-- Adicionar suporte a vídeos nos perfis
ALTER TABLE model_profiles 
ADD COLUMN IF NOT EXISTS videos TEXT[] DEFAULT '{}';

COMMENT ON COLUMN model_profiles.videos IS 'Array de URLs de vídeos do perfil da modelo';

-- Criar índice para busca de perfis com vídeos
CREATE INDEX IF NOT EXISTS idx_model_profiles_videos ON model_profiles USING GIN (videos) WHERE videos IS NOT NULL AND array_length(videos, 1) > 0;