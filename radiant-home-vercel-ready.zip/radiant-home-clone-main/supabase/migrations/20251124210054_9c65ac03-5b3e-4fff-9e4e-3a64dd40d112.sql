-- ============================================
-- FASE 2: DESTAQUES GEOGRÁFICOS
-- ============================================

-- Tabela de configurações de destaques geográficos
CREATE TABLE IF NOT EXISTS public.geographic_boosts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  geographic_type text NOT NULL CHECK (geographic_type IN ('state', 'city', 'neighborhood')),
  
  -- Campos geográficos
  state_code text,
  state_name text,
  city_slug text,
  city_name text,
  neighborhood text,
  
  -- Configurações do boost
  duration_hours integer NOT NULL DEFAULT 24,
  visibility_multiplier numeric NOT NULL DEFAULT 2.0,
  priority_score integer NOT NULL DEFAULT 100,
  
  -- Monetização
  price numeric,
  credit_cost integer,
  
  -- Metadata
  badge_text text,
  badge_color text,
  icon text,
  
  -- Status
  is_active boolean DEFAULT true,
  sort_order integer DEFAULT 0,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de ativações de destaques geográficos
CREATE TABLE IF NOT EXISTS public.active_geographic_boosts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  profile_id uuid REFERENCES public.model_profiles(id) ON DELETE CASCADE NOT NULL,
  geographic_boost_id uuid REFERENCES public.geographic_boosts(id) ON DELETE CASCADE NOT NULL,
  
  -- Tracking
  start_date timestamptz NOT NULL DEFAULT now(),
  end_date timestamptz NOT NULL,
  
  -- Métricas
  views_count integer DEFAULT 0,
  clicks_count integer DEFAULT 0,
  
  -- Pagamento
  payment_id text,
  payment_method text,
  credit_transaction_id uuid REFERENCES public.credit_transactions(id),
  
  -- Status
  status text DEFAULT 'active' CHECK (status IN ('active', 'expired', 'cancelled')),
  
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- FASE 3: NOVAS OPORTUNIDADES
-- ============================================

-- Pacotes Combinados (Bundles)
CREATE TABLE IF NOT EXISTS public.monetization_bundles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  
  -- Itens inclusos (JSONB array)
  included_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  
  -- Preço com desconto
  original_price numeric NOT NULL,
  bundle_price numeric NOT NULL,
  discount_percentage integer,
  
  -- Badge do pacote
  badge_text text,
  badge_color text,
  
  is_active boolean DEFAULT true,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Programa de Fidelidade
CREATE TABLE IF NOT EXISTS public.loyalty_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  
  -- Níveis de fidelidade
  tier text DEFAULT 'bronze' CHECK (tier IN ('bronze', 'silver', 'gold', 'platinum')),
  points integer DEFAULT 0,
  
  -- Benefícios do tier
  cashback_percentage integer DEFAULT 0,
  discount_percentage integer DEFAULT 0,
  
  -- Histórico
  total_spent numeric DEFAULT 0,
  total_cashback_earned numeric DEFAULT 0,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Publicidade para Empresas Parceiras
CREATE TABLE IF NOT EXISTS public.partner_ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  contact_email text NOT NULL,
  
  -- Conteúdo do anúncio
  ad_title text NOT NULL,
  ad_description text,
  ad_image_url text,
  target_url text,
  
  -- Segmentação geográfica
  target_states text[],
  target_cities text[],
  target_categories text[],
  
  -- Posicionamento
  placement text CHECK (placement IN ('sidebar', 'feed', 'profile_page')),
  
  -- Pagamento
  monthly_price numeric NOT NULL,
  
  -- Status e período
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  is_active boolean DEFAULT true,
  
  -- Métricas
  impressions integer DEFAULT 0,
  clicks integer DEFAULT 0,
  
  created_at timestamptz DEFAULT now()
);

-- Verificações Premium
CREATE TABLE IF NOT EXISTS public.premium_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  profile_id uuid REFERENCES public.model_profiles(id) ON DELETE CASCADE NOT NULL,
  
  -- Tipo de verificação premium
  verification_type text NOT NULL CHECK (verification_type IN (
    'video_call',
    'professional_photoshoot',
    'background_check',
    'social_media_link'
  )),
  
  -- Status
  status text DEFAULT 'pending',
  verified_at timestamptz,
  
  -- Custo
  price_paid numeric NOT NULL,
  
  created_at timestamptz DEFAULT now()
);

-- Adicionar campo auto_renew às tabelas de boosts
ALTER TABLE public.active_boosts 
ADD COLUMN IF NOT EXISTS auto_renew boolean DEFAULT false;

-- ============================================
-- RLS POLICIES
-- ============================================

-- Geographic Boosts
ALTER TABLE public.geographic_boosts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage geographic boosts"
  ON public.geographic_boosts FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view active geographic boosts"
  ON public.geographic_boosts FOR SELECT
  USING (is_active = true);

-- Active Geographic Boosts
ALTER TABLE public.active_geographic_boosts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own geographic boosts"
  ON public.active_geographic_boosts FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own geographic boosts"
  ON public.active_geographic_boosts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all geographic boosts"
  ON public.active_geographic_boosts FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- Monetization Bundles
ALTER TABLE public.monetization_bundles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage bundles"
  ON public.monetization_bundles FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view active bundles"
  ON public.monetization_bundles FOR SELECT
  USING (is_active = true);

-- Loyalty Rewards
ALTER TABLE public.loyalty_rewards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own loyalty rewards"
  ON public.loyalty_rewards FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage loyalty rewards"
  ON public.loyalty_rewards FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- Partner Ads
ALTER TABLE public.partner_ads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage partner ads"
  ON public.partner_ads FOR ALL
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view active partner ads"
  ON public.partner_ads FOR SELECT
  USING (is_active = true AND now() BETWEEN start_date AND end_date);

-- Premium Verifications
ALTER TABLE public.premium_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own premium verifications"
  ON public.premium_verifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own premium verifications"
  ON public.premium_verifications FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage premium verifications"
  ON public.premium_verifications FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- ============================================
-- TRIGGERS PARA UPDATED_AT
-- ============================================

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_geographic_boosts_updated_at
  BEFORE UPDATE ON public.geographic_boosts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_monetization_bundles_updated_at
  BEFORE UPDATE ON public.monetization_bundles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_loyalty_rewards_updated_at
  BEFORE UPDATE ON public.loyalty_rewards
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();