-- Adicionar campo auto_renew em active_premium_services se não existir
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'active_premium_services' 
    AND column_name = 'auto_renew'
  ) THEN
    ALTER TABLE public.active_premium_services 
    ADD COLUMN auto_renew BOOLEAN DEFAULT false;
  END IF;
END $$;

-- Criar tabela de configurações de auto-renovação
CREATE TABLE IF NOT EXISTS public.auto_renewal_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  profile_id UUID REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  renewal_type TEXT NOT NULL CHECK (renewal_type IN ('boost', 'premium_service', 'geographic_boost')),
  package_id UUID, -- ID do pacote de boost, serviço premium, ou boost geográfico
  is_enabled BOOLEAN DEFAULT true,
  payment_method TEXT DEFAULT 'credits' CHECK (payment_method IN ('credits', 'money')),
  last_renewal_date TIMESTAMPTZ,
  next_renewal_date TIMESTAMPTZ,
  renewal_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, profile_id, renewal_type, package_id)
);

-- Habilitar RLS
ALTER TABLE public.auto_renewal_settings ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para auto_renewal_settings
CREATE POLICY "Users can view own renewal settings"
  ON public.auto_renewal_settings
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own renewal settings"
  ON public.auto_renewal_settings
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own renewal settings"
  ON public.auto_renewal_settings
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own renewal settings"
  ON public.auto_renewal_settings
  FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all renewal settings"
  ON public.auto_renewal_settings
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Criar função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_auto_renewal_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para updated_at
DROP TRIGGER IF EXISTS update_auto_renewal_settings_updated_at ON public.auto_renewal_settings;
CREATE TRIGGER update_auto_renewal_settings_updated_at
  BEFORE UPDATE ON public.auto_renewal_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_auto_renewal_settings_updated_at();