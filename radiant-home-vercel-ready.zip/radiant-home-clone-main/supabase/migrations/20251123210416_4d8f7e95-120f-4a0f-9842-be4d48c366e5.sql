-- Adicionar estrutura de preços múltiplos e horários de disponibilidade

-- Adicionar coluna de preços estruturados (JSONB)
ALTER TABLE model_profiles 
ADD COLUMN IF NOT EXISTS pricing JSONB DEFAULT '{
  "hourly": null,
  "half_period": null,
  "overnight": null,
  "full_day": null
}'::jsonb;

-- Adicionar coluna de horários disponíveis
ALTER TABLE model_profiles 
ADD COLUMN IF NOT EXISTS available_hours TEXT[] DEFAULT ARRAY[]::TEXT[];

-- Adicionar comentários para documentação
COMMENT ON COLUMN model_profiles.pricing IS 'Estrutura de preços: hourly (hora), half_period (4h), overnight (pernoite), full_day (24h)';
COMMENT ON COLUMN model_profiles.available_hours IS 'Horários de disponibilidade: Manhã, Tarde, Noite, Madrugada, 24 Horas';