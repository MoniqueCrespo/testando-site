-- Create profile_analytics table for tracking profile views and engagement
CREATE TABLE IF NOT EXISTS public.profile_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  hour INTEGER CHECK (hour >= 0 AND hour <= 23),
  views INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  favorites INTEGER DEFAULT 0,
  messages INTEGER DEFAULT 0,
  source TEXT, -- 'feed', 'search', 'featured', 'direct', 'state', 'city'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profile_analytics ENABLE ROW LEVEL SECURITY;

-- Profile owners can view their analytics
CREATE POLICY "Profile owners can view analytics"
ON public.profile_analytics
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = profile_analytics.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

-- Admins can view all analytics
CREATE POLICY "Admins can view all analytics"
ON public.profile_analytics
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes for performance
CREATE INDEX idx_profile_analytics_profile_date ON public.profile_analytics(profile_id, date DESC);
CREATE INDEX idx_profile_analytics_source ON public.profile_analytics(source);
CREATE INDEX idx_profile_analytics_date ON public.profile_analytics(date DESC);

-- Trigger for updated_at
CREATE TRIGGER update_profile_analytics_updated_at
BEFORE UPDATE ON public.profile_analytics
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create appointments table for scheduling system
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  client_name TEXT,
  client_phone TEXT,
  client_email TEXT,
  appointment_date TIMESTAMP WITH TIME ZONE NOT NULL,
  duration_hours INTEGER DEFAULT 1,
  service_type TEXT,
  notes TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Profile owners can manage their appointments
CREATE POLICY "Profile owners can manage appointments"
ON public.appointments
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = appointments.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

-- Admins can view all appointments
CREATE POLICY "Admins can manage all appointments"
ON public.appointments
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes
CREATE INDEX idx_appointments_profile_date ON public.appointments(profile_id, appointment_date DESC);
CREATE INDEX idx_appointments_status ON public.appointments(status);

-- Trigger for updated_at
CREATE TRIGGER update_appointments_updated_at
BEFORE UPDATE ON public.appointments
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create conversations table for internal chat
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  visitor_id UUID NOT NULL,
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  unread_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

-- Profile owners can view their conversations
CREATE POLICY "Profile owners can view conversations"
ON public.conversations
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.model_profiles
    WHERE model_profiles.id = conversations.profile_id
    AND model_profiles.user_id = auth.uid()
  )
);

-- Visitors can view their own conversations
CREATE POLICY "Visitors can view their conversations"
ON public.conversations
FOR SELECT
USING (visitor_id = auth.uid());

-- Create indexes
CREATE INDEX idx_conversations_profile ON public.conversations(profile_id, last_message_at DESC);
CREATE INDEX idx_conversations_visitor ON public.conversations(visitor_id, last_message_at DESC);

-- Trigger for updated_at
CREATE TRIGGER update_conversations_updated_at
BEFORE UPDATE ON public.conversations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create messages table
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Users can view messages from their conversations
CREATE POLICY "Users can view their messages"
ON public.messages
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.conversations
    WHERE conversations.id = messages.conversation_id
    AND (
      conversations.visitor_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.model_profiles
        WHERE model_profiles.id = conversations.profile_id
        AND model_profiles.user_id = auth.uid()
      )
    )
  )
);

-- Users can send messages to their conversations
CREATE POLICY "Users can send messages"
ON public.messages
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.conversations
    WHERE conversations.id = messages.conversation_id
    AND (
      conversations.visitor_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.model_profiles
        WHERE model_profiles.id = conversations.profile_id
        AND model_profiles.user_id = auth.uid()
      )
    )
  )
);

-- Create indexes
CREATE INDEX idx_messages_conversation ON public.messages(conversation_id, created_at DESC);
CREATE INDEX idx_messages_sender ON public.messages(sender_id);
CREATE INDEX idx_messages_unread ON public.messages(is_read) WHERE is_read = false;