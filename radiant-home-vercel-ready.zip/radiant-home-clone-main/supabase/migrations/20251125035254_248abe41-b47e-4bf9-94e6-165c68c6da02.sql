-- Add CHECK constraint to ensure state is exactly 2 uppercase letters
ALTER TABLE model_profiles
ADD CONSTRAINT state_format_check CHECK (state ~ '^[A-Z]{2}$');

-- Add CHECK constraint to ensure city follows slug format (lowercase, hyphens, no special chars)
ALTER TABLE model_profiles
ADD CONSTRAINT city_slug_format_check CHECK (city ~ '^[a-z0-9]+(-[a-z0-9]+)*$');