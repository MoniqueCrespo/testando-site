-- Sprint 1: Criar estrutura completa de banco de dados para sistema de monetização

-- 1. Tabela de créditos dos usuários
CREATE TABLE public.user_credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  balance INTEGER NOT NULL DEFAULT 0,
  total_earned INTEGER NOT NULL DEFAULT 0,
  total_spent INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- 2. Tabela de pacotes de créditos
CREATE TABLE public.credit_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  credits INTEGER NOT NULL,
  bonus_credits INTEGER DEFAULT 0,
  price NUMERIC(10,2) NOT NULL,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. Tabela de transações de créditos
CREATE TABLE public.credit_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  transaction_type TEXT NOT NULL,
  description TEXT NOT NULL,
  reference_id UUID,
  payment_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. Tabela de pacotes de boost
CREATE TABLE public.boost_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  duration_hours INTEGER NOT NULL,
  visibility_multiplier NUMERIC(4,2) NOT NULL,
  price NUMERIC(10,2),
  credit_cost INTEGER,
  features JSONB DEFAULT '[]',
  badge_text TEXT,
  badge_color TEXT,
  priority_score INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 5. Tabela de boosts ativos
CREATE TABLE public.active_boosts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_id UUID NOT NULL REFERENCES model_profiles(id) ON DELETE CASCADE,
  package_id UUID NOT NULL REFERENCES boost_packages(id),
  start_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ NOT NULL,
  views_count INTEGER DEFAULT 0,
  clicks_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active',
  payment_method TEXT,
  payment_id TEXT,
  credit_transaction_id UUID REFERENCES credit_transactions(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. Tabela de serviços premium
CREATE TABLE public.premium_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  credit_cost INTEGER NOT NULL,
  duration_days INTEGER,
  service_type TEXT NOT NULL,
  config JSONB DEFAULT '{}',
  icon TEXT,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 7. Tabela de serviços premium ativos
CREATE TABLE public.active_premium_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_id UUID NOT NULL REFERENCES model_profiles(id) ON DELETE CASCADE,
  service_id UUID NOT NULL REFERENCES premium_services(id),
  start_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ,
  status TEXT DEFAULT 'active',
  credit_transaction_id UUID REFERENCES credit_transactions(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 8. Tabela de missões diárias
CREATE TABLE public.daily_missions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  mission_type TEXT NOT NULL,
  credit_reward INTEGER NOT NULL,
  target_value INTEGER DEFAULT 1,
  icon TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 9. Tabela de progresso de missões
CREATE TABLE public.user_mission_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mission_id UUID NOT NULL REFERENCES daily_missions(id),
  current_value INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, mission_id, date)
);

-- 10. Adicionar colunas à tabela premium_plans existente
ALTER TABLE public.premium_plans 
ADD COLUMN IF NOT EXISTS monthly_credits INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS discount_percentage INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS max_active_boosts INTEGER DEFAULT 1,
ADD COLUMN IF NOT EXISTS priority_support BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS advanced_analytics BOOLEAN DEFAULT false;

-- RLS Policies
ALTER TABLE user_credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE boost_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE active_boosts ENABLE ROW LEVEL SECURITY;
ALTER TABLE premium_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE active_premium_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_mission_progress ENABLE ROW LEVEL SECURITY;

-- Políticas para user_credits
CREATE POLICY "Users can view own credits"
  ON user_credits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all credits"
  ON user_credits FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas para credit_transactions
CREATE POLICY "Users can view own transactions"
  ON credit_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all transactions"
  ON credit_transactions FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas para pacotes (público)
CREATE POLICY "Anyone can view active credit packages"
  ON credit_packages FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage credit packages"
  ON credit_packages FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view active boost packages"
  ON boost_packages FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage boost packages"
  ON boost_packages FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view active premium services"
  ON premium_services FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage premium services"
  ON premium_services FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas para boosts ativos
CREATE POLICY "Users can view own boosts"
  ON active_boosts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own boosts"
  ON active_boosts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all boosts"
  ON active_boosts FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas para serviços premium ativos
CREATE POLICY "Users can view own premium services"
  ON active_premium_services FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all premium services"
  ON active_premium_services FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Políticas para missões
CREATE POLICY "Anyone can view active missions"
  ON daily_missions FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage missions"
  ON daily_missions FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view own mission progress"
  ON user_mission_progress FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own mission progress"
  ON user_mission_progress FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Trigger para atualizar updated_at em user_credits
CREATE OR REPLACE FUNCTION public.update_user_credits_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_credits_updated_at
  BEFORE UPDATE ON public.user_credits
  FOR EACH ROW
  EXECUTE FUNCTION public.update_user_credits_updated_at();

-- Popular dados iniciais
INSERT INTO credit_packages (name, credits, bonus_credits, price, sort_order) VALUES
  ('Iniciante', 100, 0, 49.90, 1),
  ('Popular', 250, 25, 99.90, 2),
  ('Avançado', 500, 100, 179.90, 3),
  ('Profissional', 1000, 250, 299.90, 4);

INSERT INTO boost_packages (name, duration_hours, visibility_multiplier, price, credit_cost, badge_text, badge_color, priority_score, features, sort_order) VALUES
  ('Boost Básico', 24, 1.5, 29.90, 50, 'Em Destaque', '#f59e0b', 10, '["Aparecer nas primeiras posições", "50% mais visualizações", "Badge especial"]', 1),
  ('Boost Plus', 168, 2.0, 79.90, 150, 'Em Alta', '#ec4899', 20, '["Destaque por 7 dias", "100% mais visualizações", "Prioridade nos resultados", "Badge Premium"]', 2),
  ('Boost Premium', 360, 3.0, 149.90, 280, 'Premium', '#8b5cf6', 30, '["Destaque por 15 dias", "200% mais visualizações", "Topo das buscas", "Badge VIP"]', 3),
  ('Boost Ultra', 720, 5.0, 249.90, 500, 'VIP', '#ef4444', 50, '["Destaque por 30 dias", "400% mais visualizações", "Posição garantida no topo", "Badge Exclusivo", "Suporte prioritário"]', 4);

INSERT INTO premium_services (name, description, credit_cost, duration_days, service_type, icon, sort_order, config) VALUES
  ('Selo Premium', 'Adiciona selo dourado ao seu perfil', 100, 7, 'badge', 'Award', 1, '{"badge_color": "#fbbf24", "benefits": ["Selo de verificação premium", "Maior credibilidade", "Destaque visual"]}'),
  ('Destaque Homepage', 'Aparece no carrossel da homepage', 200, 7, 'homepage_feature', 'Star', 2, '{"position": "carousel", "benefits": ["Exposição máxima", "Primeiras impressões", "Acesso a todos visitantes"]}'),
  ('Posição Fixa Top 3', 'Garante posição entre os 3 primeiros', 300, 7, 'top_position', 'Trophy', 3, '{"position": 3, "benefits": ["Sempre visível", "Máxima conversão", "Resultados garantidos"]}'),
  ('Story em Destaque', 'Seu story fica fixado por 24h', 50, 1, 'story_highlight', 'Zap', 4, '{"duration_hours": 24, "benefits": ["Atenção imediata", "Engajamento direto", "Novidades em destaque"]}');

INSERT INTO daily_missions (name, description, mission_type, credit_reward, target_value, icon, is_active) VALUES
  ('Adicione Fotos', 'Adicione 2 fotos novas ao seu perfil', 'upload_photo', 5, 2, 'Camera', true),
  ('Atualize Preços', 'Atualize seus preços e disponibilidade', 'update_profile', 3, 1, 'DollarSign', true),
  ('Complete Serviços', 'Adicione pelo menos 5 serviços', 'add_service', 10, 5, 'CheckCircle', true),
  ('Verificação', 'Complete a verificação de identidade', 'complete_verification', 50, 1, 'ShieldCheck', true);