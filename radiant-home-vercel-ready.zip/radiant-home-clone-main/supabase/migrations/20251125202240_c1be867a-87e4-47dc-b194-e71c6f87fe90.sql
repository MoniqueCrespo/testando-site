-- Create affiliate tiers table
CREATE TABLE IF NOT EXISTS public.affiliate_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  min_referrals INTEGER NOT NULL DEFAULT 0,
  min_revenue NUMERIC NOT NULL DEFAULT 0,
  commission_rate NUMERIC NOT NULL DEFAULT 0,
  bonus_rate NUMERIC NOT NULL DEFAULT 0,
  benefits JSONB DEFAULT '[]'::jsonb,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create affiliates table
CREATE TABLE IF NOT EXISTS public.affiliates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  affiliate_code TEXT NOT NULL UNIQUE,
  affiliate_link TEXT NOT NULL,
  commission_rate NUMERIC NOT NULL DEFAULT 10,
  tier_level TEXT DEFAULT 'bronze',
  total_earned NUMERIC DEFAULT 0,
  pending_payout NUMERIC DEFAULT 0,
  total_paid_out NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  pix_key TEXT,
  bank_info JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id)
);

-- Create affiliate referrals table
CREATE TABLE IF NOT EXISTS public.affiliate_referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id UUID NOT NULL REFERENCES public.affiliates(id) ON DELETE CASCADE,
  referred_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  first_transaction_at TIMESTAMP WITH TIME ZONE,
  total_transactions INTEGER DEFAULT 0,
  total_revenue_generated NUMERIC DEFAULT 0,
  total_commission_earned NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'churned')),
  UNIQUE(affiliate_id, referred_user_id)
);

-- Create affiliate commissions table
CREATE TABLE IF NOT EXISTS public.affiliate_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id UUID NOT NULL REFERENCES public.affiliates(id) ON DELETE CASCADE,
  referral_id UUID NOT NULL REFERENCES public.affiliate_referrals(id) ON DELETE CASCADE,
  transaction_type TEXT NOT NULL,
  transaction_id UUID NOT NULL,
  transaction_amount NUMERIC NOT NULL,
  commission_rate NUMERIC NOT NULL,
  commission_amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'paid')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create affiliate payouts table
CREATE TABLE IF NOT EXISTS public.affiliate_payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id UUID NOT NULL REFERENCES public.affiliates(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payout_method TEXT NOT NULL,
  pix_key TEXT,
  bank_info JSONB,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  processed_at TIMESTAMP WITH TIME ZONE,
  proof_url TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Insert default affiliate tiers
INSERT INTO public.affiliate_tiers (name, min_referrals, min_revenue, commission_rate, bonus_rate, benefits, sort_order)
VALUES 
  ('bronze', 0, 0, 0, 0, '["Comissão base em todas transações", "Dashboard de performance", "Materiais de divulgação"]'::jsonb, 1),
  ('silver', 5, 1000, 2, 0, '["Comissão base + 2%", "Suporte prioritário", "Relatórios avançados"]'::jsonb, 2),
  ('gold', 20, 5000, 5, 0, '["Comissão base + 5%", "Gerente de contas dedicado", "Treinamento exclusivo"]'::jsonb, 3),
  ('diamond', 50, 20000, 10, 5, '["Comissão base + 10%", "Bônus de 5%", "Eventos VIP", "Pagamentos prioritários"]'::jsonb, 4)
ON CONFLICT (name) DO NOTHING;

-- Enable RLS
ALTER TABLE public.affiliate_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_commissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_payouts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for affiliate_tiers
CREATE POLICY "Anyone can view affiliate tiers"
  ON public.affiliate_tiers FOR SELECT
  USING (true);

CREATE POLICY "Admins can manage affiliate tiers"
  ON public.affiliate_tiers FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for affiliates
CREATE POLICY "Users can view own affiliate data"
  ON public.affiliates FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own affiliate account"
  ON public.affiliates FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own affiliate data"
  ON public.affiliates FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all affiliates"
  ON public.affiliates FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for affiliate_referrals
CREATE POLICY "Affiliates can view own referrals"
  ON public.affiliate_referrals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.affiliates
      WHERE affiliates.id = affiliate_referrals.affiliate_id
      AND affiliates.user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert referrals"
  ON public.affiliate_referrals FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Admins can manage all referrals"
  ON public.affiliate_referrals FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for affiliate_commissions
CREATE POLICY "Affiliates can view own commissions"
  ON public.affiliate_commissions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.affiliates
      WHERE affiliates.id = affiliate_commissions.affiliate_id
      AND affiliates.user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert commissions"
  ON public.affiliate_commissions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Admins can manage all commissions"
  ON public.affiliate_commissions FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for affiliate_payouts
CREATE POLICY "Affiliates can view own payouts"
  ON public.affiliate_payouts FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.affiliates
      WHERE affiliates.id = affiliate_payouts.affiliate_id
      AND affiliates.user_id = auth.uid()
    )
  );

CREATE POLICY "Affiliates can request payouts"
  ON public.affiliate_payouts FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.affiliates
      WHERE affiliates.id = affiliate_payouts.affiliate_id
      AND affiliates.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all payouts"
  ON public.affiliate_payouts FOR ALL
  USING (has_role(auth.uid(), 'admin'));

-- Create indexes for better performance
CREATE INDEX idx_affiliates_user_id ON public.affiliates(user_id);
CREATE INDEX idx_affiliates_code ON public.affiliates(affiliate_code);
CREATE INDEX idx_affiliates_status ON public.affiliates(status);
CREATE INDEX idx_referrals_affiliate_id ON public.affiliate_referrals(affiliate_id);
CREATE INDEX idx_referrals_referred_user ON public.affiliate_referrals(referred_user_id);
CREATE INDEX idx_commissions_affiliate_id ON public.affiliate_commissions(affiliate_id);
CREATE INDEX idx_commissions_referral_id ON public.affiliate_commissions(referral_id);
CREATE INDEX idx_commissions_status ON public.affiliate_commissions(status);
CREATE INDEX idx_payouts_affiliate_id ON public.affiliate_payouts(affiliate_id);
CREATE INDEX idx_payouts_status ON public.affiliate_payouts(status);

-- Create updated_at trigger for affiliates
CREATE OR REPLACE FUNCTION update_affiliates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER update_affiliates_updated_at
  BEFORE UPDATE ON public.affiliates
  FOR EACH ROW
  EXECUTE FUNCTION update_affiliates_updated_at();