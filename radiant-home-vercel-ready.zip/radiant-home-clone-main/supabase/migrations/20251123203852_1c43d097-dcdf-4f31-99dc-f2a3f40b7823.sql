-- Tabela para rastrear estatísticas de perfis
CREATE TABLE IF NOT EXISTS public.profile_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  views INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  favorites INTEGER DEFAULT 0,
  messages INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela para planos premium
CREATE TABLE IF NOT EXISTS public.premium_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  duration_days INTEGER NOT NULL,
  features JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela para assinaturas premium
CREATE TABLE IF NOT EXISTS public.premium_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  profile_id UUID REFERENCES public.model_profiles(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES public.premium_plans(id),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'expired', 'cancelled')),
  payment_id TEXT,
  payment_method TEXT DEFAULT 'mercadopago',
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  auto_renew BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profile_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.premium_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.premium_subscriptions ENABLE ROW LEVEL SECURITY;

-- Policies para profile_stats
CREATE POLICY "Qualquer pessoa pode ver estatísticas"
  ON public.profile_stats FOR SELECT
  USING (true);

CREATE POLICY "Modelos podem ver suas próprias estatísticas"
  ON public.profile_stats FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.model_profiles
      WHERE model_profiles.id = profile_stats.profile_id
      AND model_profiles.user_id = auth.uid()
    )
  );

-- Policies para premium_plans
CREATE POLICY "Todos podem ver planos ativos"
  ON public.premium_plans FOR SELECT
  USING (is_active = true);

-- Policies para premium_subscriptions
CREATE POLICY "Usuários podem ver suas próprias assinaturas"
  ON public.premium_subscriptions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar suas próprias assinaturas"
  ON public.premium_subscriptions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar suas próprias assinaturas"
  ON public.premium_subscriptions FOR UPDATE
  USING (auth.uid() = user_id);

-- Triggers para updated_at
CREATE TRIGGER update_profile_stats_updated_at
  BEFORE UPDATE ON public.profile_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_premium_subscriptions_updated_at
  BEFORE UPDATE ON public.premium_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Inserir planos premium padrão
INSERT INTO public.premium_plans (name, description, price, duration_days, features) VALUES
  ('Destaque 7 dias', 'Seu anúncio em destaque por 7 dias', 49.90, 7, '["Destaque na listagem", "Selo de destaque", "Maior visibilidade"]'::jsonb),
  ('Destaque 15 dias', 'Seu anúncio em destaque por 15 dias', 89.90, 15, '["Destaque na listagem", "Selo de destaque", "Maior visibilidade", "10% de desconto"]'::jsonb),
  ('Destaque 30 dias', 'Seu anúncio em destaque por 30 dias', 149.90, 30, '["Destaque na listagem", "Selo de destaque", "Maior visibilidade", "25% de desconto"]'::jsonb);

-- Criar índices para melhor performance
CREATE INDEX idx_profile_stats_profile_id ON public.profile_stats(profile_id);
CREATE INDEX idx_premium_subscriptions_user_id ON public.premium_subscriptions(user_id);
CREATE INDEX idx_premium_subscriptions_profile_id ON public.premium_subscriptions(profile_id);
CREATE INDEX idx_premium_subscriptions_status ON public.premium_subscriptions(status);