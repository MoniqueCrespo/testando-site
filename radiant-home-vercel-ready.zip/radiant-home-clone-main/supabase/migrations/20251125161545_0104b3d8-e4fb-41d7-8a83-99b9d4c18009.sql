-- Habilitar extensão unaccent para remover acentos
CREATE EXTENSION IF NOT EXISTS unaccent;

-- Adicionar campo slug na tabela model_profiles
ALTER TABLE model_profiles 
ADD COLUMN IF NOT EXISTS slug TEXT;

-- Criar índice para buscas rápidas por slug
CREATE INDEX IF NOT EXISTS idx_model_profiles_slug ON model_profiles(slug);

-- Criar função para gerar slugs únicos
CREATE OR REPLACE FUNCTION generate_profile_slug(profile_name TEXT, profile_id UUID)
RETURNS TEXT AS $$
DECLARE
  base_slug TEXT;
  final_slug TEXT;
  counter INTEGER := 0;
BEGIN
  -- Normalizar nome para slug (remover acentos, espaços, caracteres especiais)
  base_slug := lower(regexp_replace(
    unaccent(profile_name),
    '[^a-z0-9]+', '-', 'g'
  ));
  -- Remover hífens no início e fim
  base_slug := trim(both '-' from base_slug);
  
  -- Se o slug ficou vazio, usar um padrão genérico
  IF base_slug = '' THEN
    base_slug := 'perfil';
  END IF;
  
  final_slug := base_slug;
  
  -- Verificar unicidade e adicionar contador se necessário
  WHILE EXISTS (SELECT 1 FROM model_profiles WHERE slug = final_slug AND id != profile_id) LOOP
    counter := counter + 1;
    final_slug := base_slug || '-' || counter;
  END LOOP;
  
  RETURN final_slug;
END;
$$ LANGUAGE plpgsql;

-- Popular slugs para perfis existentes
UPDATE model_profiles 
SET slug = generate_profile_slug(name, id)
WHERE slug IS NULL;

-- Tornar slug NOT NULL e UNIQUE após popular
ALTER TABLE model_profiles 
ALTER COLUMN slug SET NOT NULL;

ALTER TABLE model_profiles
ADD CONSTRAINT model_profiles_slug_unique UNIQUE (slug);

-- Criar trigger para gerar slug automaticamente em INSERT/UPDATE
CREATE OR REPLACE FUNCTION auto_generate_profile_slug()
RETURNS TRIGGER AS $$
BEGIN
  -- Se slug não foi fornecido ou está vazio, gerar automaticamente
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_profile_slug(NEW.name, NEW.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_auto_slug ON model_profiles;

CREATE TRIGGER trigger_auto_slug
BEFORE INSERT OR UPDATE ON model_profiles
FOR EACH ROW
EXECUTE FUNCTION auto_generate_profile_slug();