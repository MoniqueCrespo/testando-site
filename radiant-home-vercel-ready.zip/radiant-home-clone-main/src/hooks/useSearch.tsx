import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { brazilStates, cities } from '@/data/locations';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

export interface SearchResult {
  id: string;
  type: 'state' | 'city' | 'profile';
  title: string;
  subtitle?: string;
  url: string;
  image?: string;
}

export const useSearch = (query: string) => {
  const navigate = useNavigate();
  const [searchHistory, setSearchHistory] = useState<SearchResult[]>(() => {
    const saved = localStorage.getItem('searchHistory');
    return saved ? JSON.parse(saved) : [];
  });
  const [trendingProfiles, setTrendingProfiles] = useState<SearchResult[]>([]);
  const [trendingCities, setTrendingCities] = useState<SearchResult[]>([]);
  const [isLoadingTrends, setIsLoadingTrends] = useState(false);

  // Buscar tendências ao montar o componente
  useEffect(() => {
    const fetchTrends = async () => {
      setIsLoadingTrends(true);
      
      try {
        // Buscar perfis mais visitados
        const { data: topProfiles, error: profilesError } = await supabase
          .from('model_profiles')
          .select('id, name, city, state, category, photo_url, photos')
          .eq('is_active', true)
          .eq('moderation_status', 'approved')
          .order('created_at', { ascending: false })
          .limit(5);

        if (!profilesError && topProfiles) {
          const profileResults: SearchResult[] = topProfiles.map(profile => {
            const state = brazilStates.find(s => s.code === profile.state);
            const stateSlug = state?.code.toLowerCase() || profile.state.toLowerCase();
            const city = cities.find(c => c.slug === profile.city && c.state === state?.code);
            
            // Usar slug do perfil se disponível, senão id
            const profileIdentifier = (profile as any).slug || profile.id;
            const profileUrl = profile.category === 'mulheres'
              ? `/acompanhantes/${stateSlug}/${profile.city}/${profileIdentifier}`
              : `/acompanhantes/${stateSlug}/${profile.city}/${profile.category}/${profileIdentifier}`;
            
            return {
              id: profile.id,
              type: 'profile' as const,
              title: profile.name,
              subtitle: city && state ? `${city.name}, ${state.code}` : '',
              url: profileUrl,
              image: profile.photo_url || (profile.photos && profile.photos[0]) || undefined,
            };
          });
          
          setTrendingProfiles(profileResults);
        }

        // Buscar cidades mais populares (com mais perfis)
        const { data: citiesData, error: citiesError } = await supabase
          .from('model_profiles')
          .select('city, state')
          .eq('is_active', true)
          .eq('moderation_status', 'approved');

        if (!citiesError && citiesData) {
          // Contar perfis por cidade
          const cityCount = citiesData.reduce((acc, profile) => {
            const key = `${profile.state}:${profile.city}`;
            acc[key] = (acc[key] || 0) + 1;
            return acc;
          }, {} as Record<string, number>);

          // Ordenar e pegar top 5
          const topCities: SearchResult[] = Object.entries(cityCount)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 5)
            .map(([key, count]) => {
              const [stateSlug, citySlug] = key.split(':');
              const state = brazilStates.find(s => s.slug === stateSlug);
              const city = cities.find(c => c.slug === citySlug && c.state === state?.code);
              
              if (state && city) {
                return {
                  id: city.id,
                  type: 'city' as const,
                  title: city.name,
                  subtitle: `${count} perfis • ${state.name}`,
                  url: `/acompanhantes/${state.code.toLowerCase()}/${city.slug}/categorias`,
                };
              }
              return null;
            })
            .filter((item): item is NonNullable<typeof item> => item !== null);

          setTrendingCities(topCities);
        }
      } catch (error) {
        console.error('Erro ao buscar tendências:', error);
      } finally {
        setIsLoadingTrends(false);
      }
    };

    fetchTrends();
  }, []);

  const results = useMemo(() => {
    // Se não há query, mostrar histórico ou tendências
    if (!query || query.trim().length < 2) {
      if (searchHistory.length > 0) {
        return searchHistory.slice(0, 5);
      }
      // Se não há histórico, mostrar tendências
      return [...trendingCities, ...trendingProfiles].slice(0, 8);
    }

    const normalizedQuery = query.toLowerCase().trim();
    const searchResults: SearchResult[] = [];

    // Buscar estados
    brazilStates.forEach(state => {
      if (
        state.name.toLowerCase().includes(normalizedQuery) ||
        state.code.toLowerCase().includes(normalizedQuery)
      ) {
        searchResults.push({
          id: state.code,
          type: 'state',
          title: state.name,
          subtitle: `Estado - ${state.code}`,
          url: `/acompanhantes/${state.code.toLowerCase()}`,
        });
      }
    });

    // Buscar cidades
    cities.forEach(city => {
      if (city.name.toLowerCase().includes(normalizedQuery)) {
        const state = brazilStates.find(s => s.code === city.state);
        if (state) {
          searchResults.push({
            id: city.id,
            type: 'city',
            title: city.name,
            subtitle: `Cidade - ${state.name}`,
            url: `/acompanhantes/${state.code.toLowerCase()}/${city.slug}/categorias`,
          });
        }
      }
    });

    return searchResults.slice(0, 8);
  }, [query, searchHistory, trendingCities, trendingProfiles]);

  const addToHistory = (result: SearchResult) => {
    const newHistory = [
      result,
      ...searchHistory.filter(item => item.id !== result.id),
    ].slice(0, 10);
    
    setSearchHistory(newHistory);
    localStorage.setItem('searchHistory', JSON.stringify(newHistory));
  };

  const clearHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('searchHistory');
  };

  const handleSelect = (result: SearchResult) => {
    addToHistory(result);
    navigate(result.url);
  };

  return {
    results,
    searchHistory,
    trendingProfiles,
    trendingCities,
    isLoadingTrends,
    clearHistory,
    handleSelect,
  };
};
