import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Star, Heart, Share2, Shield, Clock, DollarSign, User, Ruler, Phone, MessageCircle, Flag, ChevronLeft, ChevronRight, ZoomIn, Send, Lock, Play, X, Camera, Eye, Scissors } from 'lucide-react';
import { useState, useEffect } from 'react';
import { MessageDialog } from '@/components/MessageDialog';
import { ProfileMap } from '@/components/ProfileMap';
import { ReviewSummary } from '@/components/ReviewSummary';
import { ReviewForm } from '@/components/ReviewForm';
import { ReviewList } from '@/components/ReviewList';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useFavorites } from '@/hooks/useFavorites';
import { useToast } from '@/hooks/use-toast';
import { brazilStates, cities, getStateBySlug, getStateByCode } from '@/data/locations';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { SubscribeModal } from '@/components/SubscribeModal';
import { StoryViewer } from '@/components/StoryViewer';
import type { Story } from '@/components/StoriesBar';
import { useProfilePlan } from '@/hooks/useProfilePlan';

// Mapeamento de categorias
const categoryNames = {
  mulheres: 'Acompanhantes',
  homens: 'Homens',
  trans: 'Trans',
  casais: 'Casais',
  massagistas: 'Massagistas'
};

const ProfileDetail = () => {
  const { state, city, category: categoryParam, profileSlug, profileId, locationOrCategory } = useParams<{
    state?: string;
    city?: string;
    category?: string;
    profileSlug?: string;
    profileId?: string;
    locationOrCategory?: string;
  }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isFavorite, toggleFavorite } = useFavorites();
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false);
  const [profile, setProfile] = useState<Tables<'model_profiles'> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [reviewRefreshTrigger, setReviewRefreshTrigger] = useState(0);
  const [isSubscribeModalOpen, setIsSubscribeModalOpen] = useState(false);
  const [stories, setStories] = useState<Story[]>([]);
  const [isStoryViewerOpen, setIsStoryViewerOpen] = useState(false);
  const [storyViewerIndex, setStoryViewerIndex] = useState(0);
  
  // Detectar o slug do perfil de múltiplas fontes possíveis
  // - profileSlug: rota de 4 níveis /acompanhantes/:state/:city/:category/:profileSlug
  // - categoryParam: rota de 3 níveis /acompanhantes/:state/:city/:profileSlug (slug está em category)
  // - profileId: rota legacy /perfil/:profileId
  const detectedSlug = profileSlug || categoryParam || profileId;
  
  // Se categoria não está na URL, assume "mulheres" como padrão (SEO)
  const category = (profileSlug && categoryParam) ? categoryParam : 'mulheres';

  // Get profile plan to check photo limit
  const { data: profilePlan } = useProfilePlan(profile?.id);

  const stateData = getStateByCode((state || '').toUpperCase());

  // Buscar perfil do Supabase
  useEffect(() => {
    const fetchProfile = async () => {
      if (!detectedSlug) {
        console.log('[ProfileDetail] Nenhum slug detectado nos parâmetros');
        setIsLoading(false);
        return;
      }
      
      console.log('[ProfileDetail] Buscando perfil por slug:', detectedSlug);
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('model_profiles')
        .select('*')
        .eq('slug', detectedSlug)
        .eq('is_active', true)
        .eq('moderation_status', 'approved')
        .maybeSingle();
      
      if (error) {
        console.error('[ProfileDetail] Erro ao buscar perfil:', error);
        setProfile(null);
      } else {
        console.log('[ProfileDetail] Perfil encontrado:', data ? `${data.name} - ${data.city}, ${data.state}` : 'null');
        setProfile(data);
      }
      setIsLoading(false);
    };
    
    fetchProfile();
  }, [detectedSlug]);

  // Buscar stories do perfil
  useEffect(() => {
    const fetchStories = async () => {
      if (!profile?.id) return;

      const { data, error } = await supabase
        .from('profile_stories')
        .select('*')
        .eq('profile_id', profile.id)
        .gte('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (!error && data) {
        setStories(data.map((story: any) => ({
          id: story.id,
          profile_id: story.profile_id,
          media_url: story.media_url,
          media_type: story.media_type,
          created_at: story.created_at,
          view_count: story.view_count || 0,
          profile: {
            name: profile.name,
            photo_url: profile.photo_url || profile.photos?.[0] || '/placeholder.svg',
            state: profile.state,
            city: profile.city,
            category: profile.category,
            verified: profile.verified || false,
            is_active: profile.is_active || false,
          },
        })));
      }
    };

    fetchStories();
  }, [profile?.id]);

  // Add Schema Markup for SEO
  useEffect(() => {
    if (!profile) return;

    const schemaMarkup = {
      "@context": "https://schema.org",
      "@type": "Person",
      "name": profile.name,
      "description": profile.description || `Perfil de ${profile.name}`,
      "image": profile.photos || [],
      "address": {
        "@type": "PostalAddress",
        "addressLocality": profile.city,
        "addressRegion": stateData?.name || state,
        "addressCountry": "BR"
      },
      "priceRange": `R$ ${profile.price}`,
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5",
        "reviewCount": "0"
      }
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schemaMarkup);
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, [profile, stateData, state]);

  // Rastrear visualização ao carregar a página
  useEffect(() => {
    if (profile?.id) {
      supabase.functions.invoke('track-profile-event', {
        body: {
          event_type: 'view',
          profile_id: profile.id,
        }
      }).catch(err => console.error('Erro ao rastrear view:', err));
    }
  }, [profile?.id]);

  // Keyboard navigation for lightbox - MOVED TO TOP
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isLightboxOpen) return;
      
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev - 1 + (profile?.photos?.length || 1)) % (profile?.photos?.length || 1));
      }
      if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev + 1) % (profile?.photos?.length || 1));
      }
      if (e.key === 'Escape') setIsLightboxOpen(false);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, profile?.photos?.length]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl">Carregando perfil...</p>
        </div>
      </div>
    );
  }

  if (!profile || !stateData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Perfil não encontrado</h2>
          <Button onClick={() => navigate('/')}>Voltar ao início</Button>
        </div>
      </div>
    );
  }

  const favorited = isFavorite(String(profile.id));

  const handleToggleFavorite = () => {
    toggleFavorite(String(profile.id));
    
    // Rastrear favorite/unfavorite
    supabase.functions.invoke('track-profile-event', {
      body: {
        event_type: favorited ? 'unfavorite' : 'favorite',
        profile_id: profile.id,
      }
    }).catch(err => console.error('Erro ao rastrear favorite:', err));
    
    toast({
      title: favorited ? "Removido dos favoritos" : "Adicionado aos favoritos",
      description: favorited ? `${profile.name} foi removido` : `${profile.name} foi adicionado`,
      duration: 2000,
    });
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${profile.name} - Perfil`,
          text: profile.description,
          url: window.location.href,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copiado!",
        description: "O link do perfil foi copiado para a área de transferência",
        duration: 2000,
      });
    }
  };

  const handleContact = (type: 'whatsapp' | 'telegram') => {
    // Rastrear clique
    supabase.functions.invoke('track-profile-event', {
      body: {
        event_type: 'click',
        profile_id: profile.id,
      }
    }).catch(err => console.error('Erro ao rastrear click:', err));
    
    if (type === 'whatsapp') {
      if (!profile.whatsapp) {
        toast({
          title: "WhatsApp não disponível",
          description: "Este perfil não possui WhatsApp cadastrado.",
          duration: 2000,
        });
        return;
      }
      
      // Limpar o número (remover caracteres não numéricos)
      const cleanNumber = profile.whatsapp.replace(/\D/g, '');
      // Abrir WhatsApp Web/App
      window.open(`https://wa.me/55${cleanNumber}`, '_blank');
    } else {
      toast({
        title: "Recurso em desenvolvimento",
        description: "Contato via Telegram em breve!",
        duration: 2000,
      });
    }
  };

  const handleReport = () => {
    toast({
      title: "Denúncia recebida",
      description: "Sua denúncia será analisada pela nossa equipe em até 24h.",
      duration: 3000,
    });
  };

  // Galeria de fotos com limite baseado no plano
  const allPhotos = profile.photos && profile.photos.length > 0
    ? profile.photos
    : profile.photo_url 
      ? [profile.photo_url]
      : ['/placeholder.svg'];
  
  const maxVisiblePhotos = profilePlan?.maxPhotos || 4;
  const photos = allPhotos.slice(0, maxVisiblePhotos);
  const hiddenPhotosCount = Math.max(0, allPhotos.length - maxVisiblePhotos);

  // Vídeos do perfil
  const videos = profile.videos && Array.isArray(profile.videos) && profile.videos.length > 0
    ? profile.videos
    : [];

  const nextPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
  };

  const prevPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  const nextLightboxPhoto = () => {
    setLightboxIndex((prev) => (prev + 1) % photos.length);
  };

  const prevLightboxPhoto = () => {
    setLightboxIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };


  // Se terminou o loading e não encontrou perfil, redireciona para 404
  if (!isLoading && !profile) {
    navigate('/404', { replace: true });
    return null;
  }

  // Helper functions for photo navigation

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>

        {/* Stories Bar */}
        {stories.length > 0 && (
          <div className="mb-6 px-4">
            <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
              {stories.map((story, index) => (
                <button
                  key={story.id}
                  onClick={() => {
                    setStoryViewerIndex(index);
                    setIsStoryViewerOpen(true);
                  }}
                  className="flex flex-col items-center gap-2 flex-shrink-0 group"
                >
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full p-[3px] bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600">
                      <div className="w-full h-full rounded-full border-2 border-background overflow-hidden">
                        <img
                          src={story.media_type === 'video' ? story.profile.photo_url : story.media_url}
                          alt={story.profile.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    {story.media_type === 'video' && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Play className="w-6 h-6 text-white drop-shadow-lg" fill="white" />
                      </div>
                    )}
                  </div>
                  <span className="text-xs text-center max-w-[64px] truncate">
                    {story.profile.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Story Viewer */}
        {isStoryViewerOpen && stories.length > 0 && (
          <StoryViewer
            stories={stories}
            initialIndex={storyViewerIndex}
            onClose={() => setIsStoryViewerOpen(false)}
          />
        )}

        <div className="grid lg:grid-cols-12 gap-6">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-8 space-y-4">
            {/* Profile Header Card */}
            <Card className="overflow-hidden">
              {/* Cover Photo */}
              <div className="relative aspect-[21/9] lg:aspect-[16/7] bg-muted group">
                <img
                  src={photos[currentPhotoIndex]}
                  alt={profile.name}
                  className="w-full h-full object-cover cursor-pointer"
                  onClick={() => {
                    setLightboxIndex(currentPhotoIndex);
                    setIsLightboxOpen(true);
                  }}
                />
                
                <button
                  onClick={prevPhoto}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
                >
                  <ChevronLeft className="w-6 h-6 text-white" />
                </button>
                
                <button
                  onClick={nextPhoto}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
                >
                  <ChevronRight className="w-6 h-6 text-white" />
                </button>

                <button
                  onClick={() => {
                    setLightboxIndex(currentPhotoIndex);
                    setIsLightboxOpen(true);
                  }}
                  className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <ZoomIn className="w-5 h-5 text-white" />
                </button>

                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {photos.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPhotoIndex(index)}
                      className={`h-1 rounded-full transition-all ${
                        index === currentPhotoIndex ? 'bg-white w-8' : 'bg-white/50 w-1'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Profile Info Section */}
              <div className="p-6">
                <div className="flex items-start gap-4 mb-6">
                  <Avatar className="h-24 w-24 border-4 border-background shadow-xl -mt-16">
                    <AvatarImage src={profile.photo_url || photos[0]} alt={profile.name} />
                    <AvatarFallback>{profile.name[0]}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 pt-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h1 className="text-2xl font-bold">{profile.name}</h1>
                          {profile.verified && (
                            <Badge variant="default" className="gap-1">
                              <Shield className="w-3 h-3" />
                              Verificado
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground mb-2">
                          <MapPin className="w-4 h-4" />
                          <span>{profile.city}, {stateData.name}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="font-medium">5.0</span>
                          </div>
                          <span className="text-muted-foreground">•</span>
                          <span className="text-muted-foreground">{profile.age} anos</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <Button size="lg" className="w-full" onClick={() => handleContact('whatsapp')}>
                    <Phone className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                  <Button size="lg" variant="outline" className="w-full" onClick={() => setIsMessageDialogOpen(true)}>
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Mensagem
                  </Button>
                </div>
              </div>
            </Card>

            {/* Lightbox fullscreen */}
            <Dialog open={isLightboxOpen} onOpenChange={setIsLightboxOpen}>
              <DialogContent className="max-w-5xl max-h-[85vh] p-0">
                <div className="relative w-full h-full flex flex-col bg-black/95">
                  {/* Header */}
                  <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/60 to-transparent p-4 flex items-center justify-between">
                    <div className="flex-1" />
                    <DialogTitle className="text-white text-center flex-1">
                      Foto {lightboxIndex + 1} de {photos.length}
                    </DialogTitle>
                    <div className="flex-1 flex justify-end">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white hover:bg-white/20 h-10 w-10"
                        onClick={() => setIsLightboxOpen(false)}
                      >
                        <X className="h-6 w-6" />
                      </Button>
                    </div>
                  </div>

                  {/* Main image */}
                  <div className="flex-1 flex items-center justify-center p-4 pt-16 pb-24 relative">
                    <img
                      src={photos[lightboxIndex]}
                      alt={`${profile.name} - Foto ${lightboxIndex + 1}`}
                      className="max-w-full max-h-[65vh] w-auto h-auto object-contain"
                    />

                    {/* Navigation buttons */}
                    <button
                      onClick={prevLightboxPhoto}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-sm hover:bg-white/20 rounded-full p-3 transition-colors"
                    >
                      <ChevronLeft className="w-8 h-8 text-white" />
                    </button>
                    
                    <button
                      onClick={nextLightboxPhoto}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-sm hover:bg-white/20 rounded-full p-3 transition-colors"
                    >
                      <ChevronRight className="w-8 h-8 text-white" />
                    </button>
                  </div>

                  {/* Thumbnails */}
                  <div className="bg-black/60 backdrop-blur-sm p-4">
                    <div className="flex gap-2 justify-center overflow-x-auto scrollbar-hide">
                      {photos.map((photo, index) => (
                        <button
                          key={index}
                          onClick={() => setLightboxIndex(index)}
                          className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden transition-all ${
                            index === lightboxIndex ? 'ring-2 ring-primary scale-110' : 'opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={photo}
                            alt={`Thumb ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Grid gallery (old dialog) */}
            <Dialog open={isGalleryOpen} onOpenChange={setIsGalleryOpen}>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Galeria de Fotos</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {photos.map((photo, index) => (
                    <img
                      key={index}
                      src={photo}
                      alt={`${profile.name} - Foto ${index + 1}`}
                      className="w-full aspect-[3/4] object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => {
                        setLightboxIndex(index);
                        setIsGalleryOpen(false);
                        setIsLightboxOpen(true);
                      }}
                    />
                  ))}
                </div>
              </DialogContent>
            </Dialog>


          {/* Seção de Fotos Visível */}
          <Card className="mb-6">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <Camera className="h-6 w-6" />
                  Fotos do Perfil
                </h2>
                <Badge variant="secondary" className="text-base">
                  {photos.length} {photos.length === 1 ? 'foto' : 'fotos'}
                  {hiddenPhotosCount > 0 && (
                    <span className="ml-1 flex items-center gap-1">• +{hiddenPhotosCount} <Lock className="h-3 w-3" /></span>
                  )}
                </Badge>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {photos.map((photo, index) => (
                  <div
                    key={index}
                    className="relative aspect-[3/4] rounded-lg overflow-hidden cursor-pointer group max-h-[280px]"
                    onClick={() => {
                      setLightboxIndex(index);
                      setIsLightboxOpen(true);
                    }}
                  >
                    <img
                      src={photo}
                      alt={`${profile.name} - Foto ${index + 1}`}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
                      <ZoomIn className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
                    </div>
                  </div>
                ))}
                
                {/* Locked Photos Placeholder */}
                {hiddenPhotosCount > 0 && (
                  <div className="relative aspect-[3/4] rounded-lg overflow-hidden border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center bg-muted/30 backdrop-blur-sm max-h-[280px]">
                    <Lock className="h-6 w-6 text-muted-foreground mb-2" />
                    <span className="text-xs font-medium text-muted-foreground text-center px-2">
                      +{hiddenPhotosCount} {hiddenPhotosCount === 1 ? 'foto' : 'fotos'}
                    </span>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="mt-3 text-xs"
                      onClick={() => navigate('/planos')}
                    >
                      Ver Todas
                    </Button>
                  </div>
                )}
              </div>
              
              {/* CTA de assinatura para clientes quando há fotos bloqueadas */}
              {hiddenPhotosCount > 0 && (
                <div className="mt-4 p-4 rounded-lg bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-full bg-primary/20">
                      <Lock className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">
                        🔒 Fotos Exclusivas
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {profile?.name} tem {hiddenPhotosCount} {hiddenPhotosCount === 1 ? 'foto exclusiva' : 'fotos exclusivas'}. Assine para desbloquear todo o conteúdo.
                      </p>
                      <Button 
                        size="sm" 
                        className="bg-gradient-to-r from-primary to-[hsl(320,75%,58%)] hover:opacity-90"
                        onClick={() => setIsSubscribeModalOpen(true)}
                      >
                        Assinar para Ver Fotos Exclusivas
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Seção de Vídeos */}
          {videos.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-6 w-6" />
                  Vídeos
                  <Badge variant="secondary" className="ml-2">
                    {videos.length} {videos.length === 1 ? 'vídeo' : 'vídeos'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {videos.map((video, index) => (
                    <div
                      key={index}
                      className="relative aspect-video rounded-lg overflow-hidden bg-black group"
                    >
                      <video
                        controls
                        className="w-full h-full object-contain"
                        poster={profile.photo_url || photos[0]}
                      >
                        <source src={video} type="video/mp4" />
                        Seu navegador não suporta o elemento de vídeo.
                      </video>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}


            {/* Content Tabs */}
            <Tabs defaultValue="sobre" className="w-full">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="sobre">Sobre</TabsTrigger>
                <TabsTrigger value="servicos">Serviços</TabsTrigger>
                <TabsTrigger value="avaliacoes">Avaliações</TabsTrigger>
              </TabsList>

              {/* About Tab */}
              <TabsContent value="sobre" className="space-y-4">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Sobre mim</h3>
                  <p className="text-muted-foreground leading-relaxed mb-6 whitespace-pre-wrap break-words">
                    {profile.description}
                  </p>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Idade</p>
                        <p className="font-semibold">{profile.age} anos</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Ruler className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Altura / Peso</p>
                        <p className="font-semibold">{profile.height}cm / {profile.weight}kg</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Eye className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Olhos</p>
                        <p className="font-semibold">{profile.eye_color}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Scissors className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Cabelos</p>
                        <p className="font-semibold">{profile.hair_color}</p>
                      </div>
                    </div>
                  </div>

                  {profile.ethnicity && (
                    <div className="mt-4 p-4 rounded-lg border">
                      <p className="text-sm text-muted-foreground mb-1">Etnia</p>
                      <p className="font-medium">{profile.ethnicity}</p>
                    </div>
                  )}
                </Card>

                {/* Map Card */}
                {profile.latitude && profile.longitude && (
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-4">Localização</h3>
                    <div className="rounded-lg overflow-hidden">
                      <ProfileMap
                        latitude={profile.latitude}
                        longitude={profile.longitude}
                        neighborhood={profile.neighborhoods?.[0] || profile.city}
                        city={profile.city}
                      />
                    </div>
                  </Card>
                )}
              </TabsContent>


              {/* Services Tab */}
              <TabsContent value="servicos">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Serviços Oferecidos</h3>
                  {profile.services && profile.services.length > 0 ? (
                    <div className="grid sm:grid-cols-2 gap-3">
                      {profile.services.map((service, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 p-3 rounded-lg border hover:border-primary/50 transition-colors"
                        >
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs">✓</span>
                          </div>
                          <span className="text-sm font-medium">{service}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">Nenhum serviço especificado</p>
                  )}

                  {profile.availability && profile.availability.length > 0 && (
                    <>
                      <Separator className="my-6" />
                      <h3 className="text-lg font-semibold mb-4">Disponibilidade</h3>
                      <div className="flex flex-wrap gap-2">
                        {profile.availability.map((day, index) => (
                          <Badge key={index} variant="secondary" className="gap-1">
                            <Clock className="w-3 h-3" />
                            {day}
                          </Badge>
                        ))}
                      </div>
                    </>
                  )}
                </Card>
              </TabsContent>

              {/* Reviews Tab */}
              <TabsContent value="avaliacoes" className="space-y-4">
                <Card className="p-6">
                  <ReviewSummary profileId={profile.id} />
                </Card>
                
                <Card className="p-6">
                  <ReviewForm
                    profileId={profile.id}
                    onSuccess={() => setReviewRefreshTrigger(prev => prev + 1)}
                  />
                </Card>

                <Card className="p-6">
                  <ReviewList profileId={profile.id} refreshTrigger={reviewRefreshTrigger} />
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-4 space-y-4">
            {/* Sticky Sidebar */}
            <div className="lg:sticky lg:top-6 space-y-4">
              {/* Price Card */}
              <Card className="p-6">
                <div className="text-center mb-4">
                  <p className="text-sm text-muted-foreground mb-2">Valor por hora</p>
                  <div className="text-4xl font-bold text-primary">
                    R$ {profile.price}
                  </div>
                </div>

                {profile.featured && (
                  <Badge className="w-full mb-4 justify-center bg-gradient-to-r from-primary to-secondary border-0 py-2">
                    ⭐ Perfil em Destaque
                  </Badge>
                )}

                <Separator className="my-4" />

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Categoria</span>
                    <Badge variant="secondary">{categoryNames[category as keyof typeof categoryNames]}</Badge>
                  </div>
                  {profile.neighborhoods && profile.neighborhoods.length > 0 && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Bairros</span>
                      <span className="font-medium text-right">{profile.neighborhoods.slice(0, 2).join(', ')}</span>
                    </div>
                  )}
                </div>
              </Card>

              {/* Quick Actions */}
              <Card className="p-4">
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleToggleFavorite}
                    className={`flex flex-col items-center gap-1 h-auto py-3 ${favorited ? 'text-primary' : ''}`}
                  >
                    <Heart className={`w-5 h-5 ${favorited ? 'fill-primary' : ''}`} />
                    <span className="text-xs">Favoritar</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleShare}
                    className="flex flex-col items-center gap-1 h-auto py-3"
                  >
                    <Share2 className="w-5 h-5" />
                    <span className="text-xs">Compartilhar</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleReport}
                    className="flex flex-col items-center gap-1 h-auto py-3"
                  >
                    <Flag className="w-5 h-5" />
                    <span className="text-xs">Denunciar</span>
                  </Button>
                </div>
              </Card>

              {/* Exclusive Content Card */}
              <Card className="p-6 border-primary/50 bg-primary/5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                    <Lock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Conteúdo Exclusivo</h3>
                    <p className="text-xs text-muted-foreground">Fotos e vídeos privados</p>
                  </div>
                </div>
                <Button
                  onClick={() => setIsSubscribeModalOpen(true)}
                  className="w-full"
                  size="lg"
                >
                  Assinar Agora
                </Button>
              </Card>

              {/* Safety Info */}
              <Card className="p-4 border-muted">
                <div className="text-xs text-muted-foreground space-y-2">
                  <p className="flex items-start gap-2">
                    <Shield className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                    <span>Seus dados estão protegidos e não serão compartilhados.</span>
                  </p>
                  <p>• Sempre combine os detalhes antes do encontro</p>
                  <p>• Relate comportamentos inadequados</p>
                  <p>• Respeite sempre os limites estabelecidos</p>
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* Dialogs */}
        <MessageDialog
          open={isMessageDialogOpen}
          onOpenChange={setIsMessageDialogOpen}
          profileName={profile.name}
        />

        <SubscribeModal
          isOpen={isSubscribeModalOpen}
          onClose={() => setIsSubscribeModalOpen(false)}
          profileId={profile.id}
          profileName={profile.name}
          profile={profile}
        />
      </main>

      <Footer />
    </div>
  );
};

export default ProfileDetail;
