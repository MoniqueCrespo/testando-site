import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import FeedCard from "@/components/FeedCard";
import FeedFilters from "@/components/FeedFilters";
import FeedCardSkeleton from "@/components/FeedCardSkeleton";
import { Loader2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FeedProfile {
  id: string;
  name: string;
  age: number;
  photos: string[];
  state: string;
  city: string;
  neighborhoods: string[];
  category: string;
  price: number;
  verified: boolean;
  rating: number | null;
  has_stories: boolean;
}

interface FilterState {
  category: string;
  state: string;
  city: string;
  neighborhoods: string[];
  priceRange: [number, number];
  onlyVerified: boolean;
  onlyWithStories: boolean;
}

const FeedExplorer = () => {
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<FeedProfile[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [filters, setFilters] = useState<FilterState>(() => {
    const saved = localStorage.getItem('feedFilters');
    return saved ? JSON.parse(saved) : {
      category: 'todos',
      state: 'todos',
      city: 'todos',
      neighborhoods: [],
      priceRange: [0, 1000],
      onlyVerified: false,
      onlyWithStories: false,
    };
  });

  const fetchProfiles = useCallback(async (offset = 0) => {
    setIsLoading(true);
    
    let query = supabase
      .from('model_profiles')
      .select(`
        id, name, age, photos, state, city, neighborhoods, 
        category, pricing, verified, 
        profile_stories(id)
      `)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .range(offset, offset + 19);
    
    if (filters.category && filters.category !== 'todos') {
      query = query.eq('category', filters.category);
    }
    if (filters.state && filters.state !== 'todos') {
      query = query.eq('state', filters.state);
    }
    if (filters.city && filters.city !== 'todos') {
      query = query.eq('city', filters.city);
    }
    if (filters.neighborhoods.length > 0) {
      query = query.overlaps('neighborhoods', filters.neighborhoods);
    }
    if (filters.onlyVerified) {
      query = query.eq('verified', true);
    }
    
    const { data, error } = await query;
    
    if (error) {
      console.error('Error fetching feed profiles:', error);
      setIsLoading(false);
      return;
    }
    
    const mappedProfiles: FeedProfile[] = (data || [])
      .map(profile => ({
        id: profile.id,
        name: profile.name,
        age: profile.age,
        photos: profile.photos || [],
        state: profile.state,
        city: profile.city,
        neighborhoods: profile.neighborhoods || [],
        category: profile.category,
        price: (profile.pricing as any)?.hourly || 0,
        verified: profile.verified || false,
        rating: null,
        has_stories: ((profile.profile_stories as any) || []).length > 0,
      }))
      .filter(p => p.photos.length > 0);
    
    const filtered = filters.onlyWithStories 
      ? mappedProfiles.filter(p => p.has_stories)
      : mappedProfiles;
    
    setProfiles(prev => offset === 0 ? filtered : [...prev, ...filtered]);
    setHasMore(data?.length === 20);
    setIsLoading(false);
  }, [filters]);

  useEffect(() => {
    setProfiles([]);
    setCurrentIndex(0);
    fetchProfiles(0);
    localStorage.setItem('feedFilters', JSON.stringify(filters));
  }, [filters, fetchProfiles]);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.innerHeight + window.scrollY;
      const threshold = document.documentElement.scrollHeight - 1000;
      
      if (scrolled >= threshold && !isLoading && hasMore) {
        fetchProfiles(profiles.length);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [profiles.length, isLoading, hasMore, fetchProfiles]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' && currentIndex < profiles.length - 1) {
        setCurrentIndex(prev => prev + 1);
        const nextCard = document.getElementById(`feed-card-${currentIndex + 1}`);
        nextCard?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      if (e.key === 'ArrowUp' && currentIndex > 0) {
        setCurrentIndex(prev => prev - 1);
        const prevCard = document.getElementById(`feed-card-${currentIndex - 1}`);
        prevCard?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, profiles.length]);

  useEffect(() => {
    const preloadImages = profiles
      .slice(currentIndex + 1, currentIndex + 4)
      .map(p => p.photos[0])
      .filter(Boolean);
    
    preloadImages.forEach(url => {
      const img = new Image();
      img.src = url;
    });
  }, [currentIndex, profiles]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header fixo */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="mx-auto max-w-full md:max-w-[450px] flex items-center gap-3 px-4 py-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="h-9 w-9"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Feed</h1>
        </div>
      </div>
      
      {/* Espaçamento para o header fixo */}
      <div className="h-[57px]" />
      
      <FeedFilters filters={filters} onFilterChange={setFilters} />
      
      <div className="feed-container mx-auto max-w-full md:max-w-[450px]">
        {profiles.length === 0 && !isLoading && (
          <div className="h-screen flex items-center justify-center text-center px-4">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Nenhum perfil encontrado</h2>
              <p className="text-muted-foreground">Tente ajustar seus filtros para ver mais resultados</p>
            </div>
          </div>
        )}
        
        {profiles.map((profile, index) => (
          <FeedCard
            key={profile.id}
            profile={profile}
            isActive={index === currentIndex}
            onInView={() => setCurrentIndex(index)}
          />
        ))}
        
        {isLoading && (
          <>
            <FeedCardSkeleton />
            <FeedCardSkeleton />
          </>
        )}
        
        {isLoading && profiles.length > 0 && (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
      </div>
      
      <style>{`
        .feed-container {
          scroll-snap-type: y mandatory;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;
        }
        
        .feed-container > div {
          scroll-snap-align: start;
          scroll-snap-stop: always;
        }
        
        @media (min-width: 768px) {
          .feed-container {
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.3);
          }
        }
      `}</style>
    </div>
  );
};

export default FeedExplorer;
