import { useState, useEffect, useMemo } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import StateCard from "@/components/StateCard";
import ProfileCard from "@/components/ProfileCard";
import ProfileListItem from "@/components/ProfileListItem";
import FilterBar from "@/components/FilterBar";
import AdvancedFilters from "@/components/AdvancedFilters";
import { StoriesBar } from "@/components/StoriesBar";
import { PillButton } from "@/components/PillButton";
import { useFilters } from "@/hooks/useFilters";
import { useFavorites } from "@/hooks/useFavorites";
import { brazilStates, getStateBySlug, getCityBySlug } from "@/data/locations";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Search, MapPin, ChevronLeft, ChevronRight, Sparkles, User, Users, Heart, Palmtree, UserCog, Navigation, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import SEOContent from "@/components/SEOContent";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

interface StateWithCount {
  state: typeof brazilStates[0];
  count: number;
}

interface CategoryCount {
  category: string;
  count: number;
}

const BATCH_SIZE = 24;

const Home = () => {
  const navigate = useNavigate();
  const [statesWithCounts, setStatesWithCounts] = useState<StateWithCount[]>([]);
  const [categoryCounts, setCategoryCounts] = useState<CategoryCount[]>([]);
  const [profiles, setProfiles] = useState<Tables<'model_profiles'>[]>([]);
  const [premiumProfiles, setPremiumProfiles] = useState<Tables<'model_profiles'>[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [activeTab, setActiveTab] = useState<'profiles' | 'states'>('profiles');
  const [displayedCount, setDisplayedCount] = useState(BATCH_SIZE);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);

  const {
    filters,
    updateFilter,
    resetFilters,
    savedFilters,
    saveCurrentFilters,
    loadSavedFilter,
    deleteSavedFilter,
  } = useFilters();

  const { favorites } = useFavorites();

  // Atualizar carrossel quando categoria muda
  useEffect(() => {
    const fetchPremiumProfiles = async () => {
      let query = supabase
        .from('model_profiles')
        .select('*')
        .eq('is_active', true)
        .eq('moderation_status', 'approved')
        .eq('featured', true);

      // Filtrar por categoria se não for "Todos"
      if (selectedCategory !== 'Todos' && selectedCategory !== 'Destaque' && selectedCategory !== 'Verificados') {
        // Converter "Acompanhantes" para "mulheres" antes de fazer a query
        const categoryForQuery = selectedCategory === 'Acompanhantes' ? 'mulheres' : selectedCategory.toLowerCase();
        query = query.eq('category', categoryForQuery);
      }

      const { data: premiumData, error: premiumError } = await query
        .order('created_at', { ascending: false })
        .limit(12);

      if (premiumError) {
        console.error('Error fetching premium profiles:', premiumError);
      } else {
        setPremiumProfiles(premiumData || []);
      }
    };

    fetchPremiumProfiles();
  }, [selectedCategory]);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      // Buscar todos os perfis ativos
      const { data: profilesData, error: profilesError } = await supabase
        .from('model_profiles')
        .select('*')
        .eq('is_active', true)
        .eq('moderation_status', 'approved')
        .order('featured', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(200);

      if (profilesError) {
        console.error('Error fetching profiles:', profilesError);
      } else {
        setProfiles(profilesData || []);
      }

      // Buscar contagem por estado
      const countsPromises = brazilStates.map(async (state) => {
        const { count } = await supabase
          .from('model_profiles')
          .select('*', { count: 'exact', head: true })
          .eq('state', state.slug)
          .eq('is_active', true)
          .eq('moderation_status', 'approved');
        
        return {
          state,
          count: count || 0
        };
      });

      const results = await Promise.all(countsPromises);
      const sorted = results.sort((a, b) => b.count - a.count);
      
      setStatesWithCounts(sorted);

      // Buscar contagem por categoria
      const categories = ['mulheres', 'homens', 'trans', 'casais', 'massagistas'];
      const categoryCountsPromises = categories.map(async (category) => {
        const { count } = await supabase
          .from('model_profiles')
          .select('*', { count: 'exact', head: true })
          .eq('category', category)
          .eq('is_active', true)
          .eq('moderation_status', 'approved');
        
        return {
          category,
          count: count || 0
        };
      });

      const categoryResults = await Promise.all(categoryCountsPromises);
      setCategoryCounts(categoryResults);

      setIsLoading(false);
    };

    fetchData();
  }, []);

  // Transformar perfil do Supabase para formato do componente
  const transformProfile = (profile: Tables<'model_profiles'>) => {
    const state = getStateBySlug(profile.state);
    const city = getCityBySlug(profile.city, state?.code || '');
    
    return {
      ...profile,
      id: profile.id,
      slug: (profile as any).slug, // Campo slug adicionado para URLs amigáveis
      location: `${city?.name || profile.city}, ${state?.code || profile.state}`,
      image: profile.photo_url || profile.photos?.[0] || '/placeholder.svg',
      rating: 4.5,
      tags: [],
      isNew: new Date(profile.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
      isOnline: Math.random() > 0.5,
      eyeColor: profile.eye_color,
      hairColor: profile.hair_color,
    };
  };

  // Filtrar perfis com filtros avançados
  const filteredProfiles = useMemo(() => {
    return profiles.filter(profile => {
      // Filtro de favoritos
      if (showOnlyFavorites && !favorites.includes(profile.id)) return false;

      // Filtro de busca
      if (searchTerm.trim()) {
        const search = searchTerm.toLowerCase();
        const matchesName = profile.name.toLowerCase().includes(search);
        const state = getStateBySlug(profile.state);
        const city = getCityBySlug(profile.city, state?.code || '');
        const matchesState = state?.name.toLowerCase().includes(search);
        const matchesCity = city?.name.toLowerCase().includes(search);
        
        if (!matchesName && !matchesState && !matchesCity) return false;
      }

      // Filtros avançados
      if (profile.age < filters.ageRange[0] || profile.age > filters.ageRange[1]) return false;
      if (profile.price < filters.priceRange[0] || profile.price > filters.priceRange[1]) return false;
      if (profile.height && (profile.height < filters.height[0] || profile.height > filters.height[1])) return false;
      if (profile.weight && (profile.weight < filters.weight[0] || profile.weight > filters.weight[1])) return false;
      
      if (filters.eyeColor.length > 0 && profile.eye_color && !filters.eyeColor.includes(profile.eye_color)) return false;
      if (filters.hairColor.length > 0 && profile.hair_color && !filters.hairColor.includes(profile.hair_color)) return false;
      if (filters.services.length > 0 && profile.services && !filters.services.some(s => profile.services.includes(s))) return false;
      if (filters.availability.length > 0 && profile.availability && !filters.availability.some(a => profile.availability.includes(a))) return false;
      if (filters.neighborhoods.length > 0 && profile.neighborhoods && !filters.neighborhoods.some(n => profile.neighborhoods.includes(n))) return false;

      // Filtro de categoria
      if (selectedCategory !== 'Todos') {
        if (selectedCategory === 'Destaque' && !profile.featured) return false;
        if (selectedCategory === 'Verificados' && !profile.verified) return false;
        if (selectedCategory === 'Acompanhantes' && profile.category !== 'mulheres') return false;
        if (selectedCategory === 'Homens' && profile.category !== 'homens') return false;
        if (selectedCategory === 'Trans' && profile.category !== 'trans') return false;
        if (selectedCategory === 'Casais' && profile.category !== 'casais') return false;
        if (selectedCategory === 'Massagistas' && profile.category !== 'massagistas') return false;
      }

      return true;
    });
  }, [profiles, searchTerm, selectedCategory, filters, showOnlyFavorites, favorites]);

  // Filtrar estados pela busca
  const filteredStates = statesWithCounts.filter(({ state }) =>
    state.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Scroll infinito
  const displayedProfiles = filteredProfiles.slice(0, displayedCount);
  const hasMore = displayedCount < filteredProfiles.length;

  // Reset displayedCount quando filtros mudam
  useEffect(() => {
    setDisplayedCount(BATCH_SIZE);
  }, [searchTerm, selectedCategory, filters, showOnlyFavorites]);

  // Infinite scroll listener
  useEffect(() => {
    const handleScroll = () => {
      if (activeTab !== 'profiles') return;
      
      const scrolled = window.innerHeight + window.scrollY;
      const threshold = document.documentElement.scrollHeight - 500;
      
      if (scrolled >= threshold && !isLoadingMore && hasMore) {
        setIsLoadingMore(true);
        setTimeout(() => {
          setDisplayedCount(prev => prev + BATCH_SIZE);
          setIsLoadingMore(false);
        }, 300);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoadingMore, hasMore, activeTab]);

  // Handler para toggle de favoritos
  const handleToggleFavorites = () => {
    setShowOnlyFavorites(prev => !prev);
    if (!showOnlyFavorites && favorites.length === 0) {
      toast.info("Você ainda não tem favoritos salvos");
    }
  };


  const categoryInfo = {
    mulheres: { name: 'Acompanhantes', icon: User, color: 'text-pink-500', bgColor: 'bg-pink-50 dark:bg-pink-950' },
    homens: { name: 'Homens', icon: User, color: 'text-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-950' },
    trans: { name: 'Trans', icon: Heart, color: 'text-purple-500', bgColor: 'bg-purple-50 dark:bg-purple-950' },
    casais: { name: 'Casais', icon: Users, color: 'text-rose-500', bgColor: 'bg-rose-50 dark:bg-rose-950' },
    massagistas: { name: 'Massagistas', icon: Palmtree, color: 'text-emerald-500', bgColor: 'bg-emerald-50 dark:bg-emerald-950' },
  };

  // Total de perfis vem da soma das categorias, não dos estados
  const totalProfiles = categoryCounts.reduce((sum, { count }) => sum + count, 0);

  // Função de geolocalização
  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      toast.error("Geolocalização não é suportada pelo seu navegador");
      return;
    }

    setIsLocating(true);
    
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          // Usar API de geocoding reverso do Nominatim (OpenStreetMap - gratuito)
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&accept-language=pt-BR`
          );
          
          const data = await response.json();
          
          // Extrair estado do resultado
          const stateFromAPI = data.address?.state;
          
          if (stateFromAPI) {
            // Encontrar o estado correspondente nos nossos dados
            const matchedState = brazilStates.find(state => 
              state.name.toLowerCase().includes(stateFromAPI.toLowerCase()) ||
              stateFromAPI.toLowerCase().includes(state.name.toLowerCase())
            );
            
            if (matchedState) {
              toast.success(`Localização detectada: ${matchedState.name}`);
              navigate(`/acompanhantes/${matchedState.code.toLowerCase()}`);
            } else {
              toast.error("Estado não encontrado em nossa base de dados");
            }
          } else {
            toast.error("Não foi possível determinar sua localização");
          }
        } catch (error) {
          console.error("Erro ao buscar localização:", error);
          toast.error("Erro ao processar sua localização");
        } finally {
          setIsLocating(false);
        }
      },
      (error) => {
        console.error("Erro de geolocalização:", error);
        setIsLocating(false);
        
        if (error.code === error.PERMISSION_DENIED) {
          toast.error("Permissão de localização negada");
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          toast.error("Localização indisponível");
        } else {
          toast.error("Erro ao obter localização");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="SCORT BRASIL | Acompanhantes em Todo o Brasil"
        description={`Encontre acompanhantes em todo o Brasil na SCORT BRASIL. ${totalProfiles} perfis verificados em ${brazilStates.length} estados. Anúncios atualizados e confiáveis.`}
        keywords="scort brasil, acompanhantes brasil, escorts brasil, acompanhantes, perfis verificados"
        canonical={window.location.origin}
      />
      
      <Header />

      {/* Stories Bar */}
      <StoriesBar />

      <main className="container mx-auto px-4 py-6">
        {/* Hero Section - Alinhado à esquerda */}
        <section className="mb-6">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3 text-left">
            Acompanhantes Brasil
          </h1>
          <p className="text-base text-muted-foreground text-left">
            {isLoading ? (
              "Carregando perfis..."
            ) : (
              `${totalProfiles.toLocaleString('pt-BR')} perfis verificados • ${brazilStates.length} estados • Anúncios atualizados`
            )}
          </p>
        </section>

        {/* Categorias - Horizontal Scroll Compacto */}
        {!isLoading && categoryCounts.length > 0 && (
          <section className="mb-6">
            <ScrollArea className="w-full">
              <div className="flex gap-1.5 pb-2">
                {/* Botão "Todos" */}
                <PillButton
                  selected={selectedCategory === 'Todos'}
                  onClick={() => {
                    setActiveTab('profiles');
                    setSelectedCategory('Todos');
                  }}
                >
                  Todos ({totalProfiles.toLocaleString('pt-BR')})
                </PillButton>

                {/* Categorias dinâmicas */}
                {categoryCounts.map(({ category, count }) => {
                  const info = categoryInfo[category as keyof typeof categoryInfo];
                  if (!info) return null;
                  
                  const isSelected = selectedCategory === info.name;
                  
                  return (
                    <PillButton
                      key={category}
                      selected={isSelected}
                      onClick={() => {
                        setActiveTab('profiles');
                        setSelectedCategory(isSelected ? 'Todos' : info.name);
                      }}
                    >
                      {info.name} ({count.toLocaleString('pt-BR')})
                    </PillButton>
                  );
                })}
              </div>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </section>
        )}

        {/* Tabs - Perfis ou Estados */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'profiles' | 'states')} className="mb-6">
          <TabsList className="grid w-full max-w-sm grid-cols-2 h-10">
            <TabsTrigger value="profiles" className="text-sm">
              <Users className="w-4 h-4" />
              Perfis ({filteredProfiles.length})
            </TabsTrigger>
            <TabsTrigger value="states" className="text-sm">
              <MapPin className="w-4 h-4" />
              Estados ({filteredStates.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profiles" className="mt-6 space-y-6">
            {/* Carrossel de Perfis Premium - Compacto e Filtrado por Categoria */}
            {!isLoading && premiumProfiles.length > 0 && !searchTerm && (
              <section className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-bold text-foreground">Perfis em Destaque</h2>
                    {selectedCategory !== 'Todos' && selectedCategory !== 'Destaque' && selectedCategory !== 'Verificados' && (
                      <Badge variant="outline" className="text-xs">• {selectedCategory}</Badge>
                    )}
                  </div>
                  <Badge variant="secondary" className="text-xs">Premium</Badge>
                </div>
                
                <Carousel
                  opts={{
                    align: "start",
                    loop: true,
                  }}
                  className="w-full"
                >
                  <CarouselContent>
                    {premiumProfiles.map((profile) => {
                      const transformed = transformProfile(profile);
                      return (
                        <CarouselItem key={profile.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                          <ProfileCard 
                            {...transformed}
                            state={profile.state}
                            city={profile.city}
                            category={profile.category}
                            services={profile.services || []}
                          />
                        </CarouselItem>
                      );
                    })}
                  </CarouselContent>
                  <CarouselPrevious />
                  <CarouselNext />
                </Carousel>
              </section>
            )}
            
            <div className="mb-4">
              <FilterBar
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                onFiltersClick={() => setFiltersOpen(!filtersOpen)}
                showOnlyFavorites={showOnlyFavorites}
                onToggleFavorites={handleToggleFavorites}
              />
            </div>

            <AdvancedFilters
              open={filtersOpen}
              onOpenChange={setFiltersOpen}
              filters={filters}
              onFilterChange={updateFilter}
              onReset={resetFilters}
              savedFilters={savedFilters}
              onSaveFilters={saveCurrentFilters}
              onLoadFilter={loadSavedFilter}
              onDeleteFilter={deleteSavedFilter}
            />

            {isLoading ? (
              <div className="text-center py-12">
                <p className="text-lg text-muted-foreground">Carregando perfis...</p>
              </div>
            ) : filteredProfiles.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-lg text-muted-foreground mb-3">
                  Nenhum perfil encontrado
                </p>
                <Button onClick={resetFilters} variant="outline" size="sm">
                  Limpar Filtros
                </Button>
              </div>
              ) : (
                <>
                  {viewMode === 'grid' ? (
                    <article className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                      {displayedProfiles.map((profile) => {
                        const transformed = transformProfile(profile);
                        return (
                          <ProfileCard 
                            key={profile.id}
                            {...transformed}
                            state={profile.state}
                            city={profile.city}
                            category={profile.category}
                            services={profile.services || []}
                          />
                        );
                      })}
                    </article>
                  ) : (
                    <article className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {displayedProfiles.map((profile) => {
                        const transformed = transformProfile(profile);
                        return (
                          <ProfileListItem 
                            key={profile.id}
                            {...transformed}
                            state={profile.state}
                            city={profile.city}
                            category={profile.category}
                            services={profile.services || []}
                          />
                        );
                      })}
                    </article>
                  )}

                  {/* Loading indicator para scroll infinito */}
                  {displayedProfiles.length > 0 && (isLoadingMore || hasMore) && (
                    <div className="flex justify-center py-8 mt-6">
                      {isLoadingMore ? (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>Carregando mais perfis...</span>
                        </div>
                      ) : hasMore && (
                        <p className="text-sm text-muted-foreground">Role para carregar mais perfis</p>
                      )}
                    </div>
                  )}
                </>
              )}

            {/* Conteúdo SEO */}
            {!isLoading && <SEOContent />}
          </TabsContent>

          <TabsContent value="states" className="mt-8 space-y-4">
            {/* Busca rápida de estados */}
            <div className="max-w-md mx-auto mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Buscar estado..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10"
                />
              </div>
            </div>

            <section>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold text-foreground">
                  Selecione um Estado
                </h2>
              </div>

              {isLoading ? (
                <div className="text-center py-12">
                  <p className="text-lg text-muted-foreground">Carregando estados...</p>
                </div>
              ) : filteredStates.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-lg text-muted-foreground">
                    Nenhum estado encontrado
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredStates.map(({ state, count }) => (
                    <StateCard 
                      key={state.code} 
                      state={state} 
                      profileCount={count}
                    />
                  ))}
                </div>
              )}
            </section>
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
};

export default Home;
