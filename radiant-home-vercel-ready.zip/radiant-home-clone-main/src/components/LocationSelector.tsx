import GlobalBreadcrumbs from './GlobalBreadcrumbs';

const LocationSelector = () => {
  // LocationSelector agora é apenas um wrapper para GlobalBreadcrumbs
  // mantido para compatibilidade com código existente
  return <GlobalBreadcrumbs />;
};

export default LocationSelector;
